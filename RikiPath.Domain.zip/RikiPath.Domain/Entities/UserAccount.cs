using RikiPath.Domain.Enums;

namespace RikiPath.Domain.Entities
{
    public class UserAccount : Base
    {
        public int Id { get; set; }
        public byte[] PasswordHash { get; set; }
        public byte[] PasswordSalt { get; set; }
        public string? FirstName { get; set; }
        public string? LastName { get; set; }
        public string? Email { get; set; }
        public string? PhoneNumber { get; set; }
        public string? FirebaseUid { get; set; }
        public string? GoogleSubject { get; set; }
        public bool IsPhoneVerified { get; set; } = false;
        public bool IsEmailVerified { get; set; } = false;
        public Role Role { get; set; }
        public string? AvatarUrl { get; set; }

        public bool SystemNotificationsEnabled { get; set; } = true;
        public bool EmailNotificationsEnabled { get; set; } = true;
        public int? DailyStudyMinutesMin { get; set; }
        public int? DailyStudyMinutesMax { get; set; }
        public int DailyStudyMinutes { get; set; } = 30;

        /// <summary>Which certification level the learner is currently targeting — e.g. "JLPT N4".</summary>
        public int? TargetCertificateLevelId { get; set; }
        public string? DeclaredJlptCertificateCode { get; set; }
        public CertificateLevel? TargetCertificateLevel { get; set; }
        /// <summary>Self-selected starting level; never inferred from an assessment.</summary>
        public int? StartingCertificateLevelId { get; set; }
        public CertificateLevel? StartingCertificateLevel { get; set; }
        /// <summary>Only a valid completed Placement Test may set this value.</summary>
        public int? AssessedCertificateLevelId { get; set; }
        public CertificateLevel? AssessedCertificateLevel { get; set; }
        /// <summary>Learner-reported JLPT certificate; not a verified assessment.</summary>
        public int? SelfDeclaredCertificateLevelId { get; set; }
        public CertificateLevel? SelfDeclaredCertificateLevel { get; set; }
        /// <summary>Optimistic concurrency token for complete learning-goal writes.</summary>
        public int LearningGoalVersion { get; set; }
        public PlacementDecision PlacementDecision { get; set; } = PlacementDecision.NotTaken;
        public LearningMode LearningMode { get; set; } = LearningMode.Standard;
        public DateTime? TargetExamDate { get; set; }
        public string? StudyTimePreference { get; set; }

        // Learning history / streaks
        public int CurrentStreak { get; set; }
        public int LongestStreak { get; set; }
        public DateTime? LastStudyDate { get; set; }

        // ---- Navigation properties ----

        // As a Content Author
        public List<Lesson>? AuthoredLessons { get; set; }
        public List<Kanji>? AuthoredKanjis { get; set; }
        public List<Vocabulary>? AuthoredVocabularies { get; set; }
        public List<GrammarPattern>? AuthoredGrammarPatterns { get; set; }
        public List<MockTest>? AuthoredMockTests { get; set; }

        // As Admin reviewer: KHÔNG dùng FK nữa — Lesson/Kanji/Vocabulary/GrammarPattern/
        // MockTest lưu thẳng ReviewedByName (string) vì hệ thống chỉ có 1 Admin duy nhất.

        // As a Learner
        public List<LessonProgress>? LessonProgresses { get; set; }
        public List<LearnerNote>? LearnerNotes { get; set; }
        public List<MockTestAttempt>? MockTestAttempts { get; set; }
        public List<RecommendedLearningPath>? RecommendedLearningPaths { get; set; }
        public List<PracticeSubmission>? PracticeSubmissions { get; set; }
        public List<ReviewCard>? ReviewCards { get; set; }
        public List<LearnerEssay>? LearnerEssays { get; set; }
        public List<UserSubscription>? UserSubscriptions { get; set; }
        public List<AiCreditTopUp>? AiCreditTopUps { get; set; }

        // As a Mentor
        public List<Note>? Notes { get; set; }
        public List<MentorAvailability>? MentorAvailabilities { get; set; }
        public MentorProfile? MentorProfile { get; set; }

        // Shared
        public List<EmailVerification>? EmailVerifications { get; set; }
        public List<Notification>? Notifications { get; set; }
    }
}
