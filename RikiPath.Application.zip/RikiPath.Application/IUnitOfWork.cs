using RikiPath.Application.IRepositories;
using RikiPath.Domain.Entities;

namespace RikiPath.Application
{
    public interface IUnitOfWork
    {
        // 1. Users & Core Auth
        IUserAccountRepository UserAccounts { get; }
        IEmailVerificationRepository EmailVerifications { get; }
        INotificationRepository Notifications { get; }
        IUserDeviceTokenRepository UserDeviceTokens { get; }

        // 2. Master Data / CertificateTypes & LanguageSkills
        ICertificateTypeRepository CertificateTypes { get; }
        ICertificateLevelRepository CertificateLevels { get; }
        ICertificateSectionRepository CertificateSections { get; }
        ILanguageSkillRepository LanguageSkills { get; }

        // 3. Lessons & Learning Progress
        ILessonRepository Lessons { get; }
        ITopicRepository Topics { get; }
        ILessonProgressRepository LessonProgresses { get; }

        // 4. Content Banks
        IKanjiRepository Kanjis { get; }
        IKanaCharacterRepository KanaCharacters { get; }
        IKanaWritingPracticeCardRepository KanaWritingPracticeCards { get; }
        IKanaWritingPracticeHistoryRepository KanaWritingPracticeHistories { get; }
        IVocabularyRepository Vocabularies { get; }
        IGrammarPatternRepository GrammarPatterns { get; }
        IContentLevelMappingRepository ContentLevelMappings { get; }
        ILessonKanjiRepository LessonKanjis { get; }
        ILessonVocabularyRepository LessonVocabularies { get; }
        ILessonGrammarRepository LessonGrammars { get; }

        // 5. Personal Vocabulary Notebook
        ILearnerNoteRepository LearnerNotes { get; }
        ILearnerNoteEntryRepository LearnerNoteEntries { get; }
        ILearnerEssayRepository LearnerEssays { get; }

        // 6. JLPT Practice Tests & Submissions
        IMockTestRepository MockTests { get; }
        IMockTestSectionRepository MockTestSections { get; }
        IMockQuestionRepository MockQuestions { get; }
        IMockQuestionOptionRepository MockQuestionOptions { get; }
        IMockTestAttemptRepository MockTestAttempts { get; }
        IMockTestAnswerRepository MockTestAnswers { get; }
        IMockTestSectionResultRepository MockTestSectionResults { get; }
        IPracticeExerciseRepository PracticeExercises { get; }
        IPracticeExerciseAttemptRepository PracticeExerciseAttempts { get; }
        IPracticeQuestionRepository PracticeQuestions { get; }
        IPracticeQuestionOptionRepository PracticeQuestionOptions { get; }
        ILearnerPracticeAnswerRepository LearnerPracticeAnswers { get; }
        IHomeworkAssignmentRepository HomeworkAssignments { get; }
        IHomeworkSubmissionRepository HomeworkSubmissions { get; }
        IPracticeSubmissionRepository PracticeSubmissions { get; }
        IGradingResultRepository GradingResults { get; }

        // 7. Spaced-Repetition Review Queue (SM-2)
        IReviewCardRepository ReviewCards { get; }
        IReviewHistoryRepository ReviewHistories { get; }

        // 8. Subscriptions, Monetization & AI Advisory
        ISubscriptionPlanRepository SubscriptionPlans { get; }
        IFeatureRepository Features { get; }
        IUserSubscriptionRepository UserSubscriptions { get; }
        IAiCreditTopUpRepository AiCreditTopUps { get; }
        IRecommendedLearningPathRepository RecommendedLearningPaths { get; }

        // 9. Paid Mentor 1-1 Service
        IMentorBookingRepository MentorBookings { get; }
        IMentorReviewRepository MentorReviews { get; }
        IMentorChatMessageRepository MentorChatMessages { get; }
        INoteRepository Notes { get; }
        IMentorAvailabilityRepository MentorAvailabilities { get; }
        IMentorWeeklyAvailabilityRepository MentorWeeklyAvailabilities { get; }
        IMentorProfileRepository MentorProfiles { get; }
        IMentorScheduleRepository MentorSchedules { get; }
        IMentorCreditLedgerRepository MentorCreditLedger { get; }
        IGenericRepository<MentorTeachingQualification> MentorTeachingQualifications { get; }
        void AddMentorOutboxEvent(MentorOutboxEvent outboxEvent);

        IContentApprovalRequestRepository ContentApprovalRequests { get; }

        IContentAiReviewRepository ContentAiReviews { get; }
        IStudyCourseRepository StudyCourses { get; }
        IGenericRepository<StudyCoursePlan> StudyCoursePlans { get; }
        IGenericRepository<StudyCohort> StudyCohorts { get; }
        IGenericRepository<CohortEnrollmentEntitlement> CohortEnrollmentEntitlements { get; }
        IGenericRepository<CourseScheduleRequest> CourseScheduleRequests { get; }
        IGenericRepository<CohortTransferRequest> CohortTransferRequests { get; }
        IGenericRepository<StudyCohortMentorAssignment> StudyCohortMentorAssignments { get; }
        IGenericRepository<CohortScheduleRequest> CohortScheduleRequests { get; }
        IGenericRepository<CohortMentorReview> CohortMentorReviews { get; }
        IGenericRepository<CohortComplaint> CohortComplaints { get; }
        IGenericRepository<JlptExamSchedule> JlptExamSchedules { get; }

        // Db Helpers
        Task<int> SaveChangesAsync(CancellationToken cancellationToken = default);
        Task ExecuteInTransactionAsync(
            Func<CancellationToken, Task> operation,
            CancellationToken cancellationToken = default);
        Task ExecuteLessonTopicApprovalAsync(Func<CancellationToken, Task> operation, CancellationToken cancellationToken);
        Task ExecuteContentAuthorWriteAsync(int authorId, Func<CancellationToken, Task> operation, CancellationToken cancellationToken);
        Task<T> ExecuteScalarAsync<T>(string sql);
        Task ExecuteRawSqlAsync(string sql);
    }
}
