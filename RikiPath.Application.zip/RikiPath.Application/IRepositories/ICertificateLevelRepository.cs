using RikiPath.Domain.Entities;

namespace RikiPath.Application.IRepositories
{
    public interface ICertificateLevelRepository : IGenericRepository<CertificateLevel>
    {
        Task<IReadOnlyList<CertificateLevel>> GetLevelsByCertificateTypeIdAsync(int certificationId, CancellationToken ct = default);
        Task<IReadOnlyList<CertificateLevel>> GetLearnerVisibleJlptLevelsAsync(CancellationToken ct = default);
        Task<CertificateLevel?> GetActiveJlptLevelByIdAsync(int id, CancellationToken ct = default);
    }
}
