using RikiPath.Application.Requests.Lessons;
using RikiPath.Application.Responses;
using RikiPath.Application.Responses.Lessons;

namespace RikiPath.Application.IServices
{
    public interface ILessonProgressService
    {
        Task<ApiResponse<LearningDiscoveryResponse>> GetLearningDiscoveryAsync(
            int certificateLevelId,
            CancellationToken cancellationToken);

        Task<ApiResponse<LessonDetailResponse>> GetLessonDetailAsync(int lessonId, CancellationToken cancellationToken);

        /// <summary>
        /// Lưu vị trí phát video hiện tại (resume), tự tính lại % tiến độ, và tự động đánh dấu
        /// hoàn thành khi progress &gt;= 95% (ngưỡng tránh trường hợp video kết thúc lệch vài giây).
        /// </summary>
        Task<ApiResponse<LessonDetailResponse>> UpdatePlaybackPositionAsync(int lessonId, UpdatePlaybackPositionRequest request, CancellationToken cancellationToken);

        Task<ApiResponse<LessonDetailResponse>> CompleteLessonAsync(
            int lessonId,
            CancellationToken cancellationToken);
    }
}
