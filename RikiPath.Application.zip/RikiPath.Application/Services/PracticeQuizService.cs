using Microsoft.EntityFrameworkCore;
using RikiPath.Application;
using RikiPath.Application.IServices;
using RikiPath.Application.Requests.PracticeExercises;
using RikiPath.Application.Responses;
using RikiPath.Application.Responses.PracticeExercises;
using RikiPath.Domain.Entities;
using System.Net;

namespace RikiPath.Application.Services;

public class PracticeQuizService(
    IUnitOfWork unitOfWork,
    IClaimService claimService,
    ILearningPathService learningPathService,
    IStandardRoadmapService? standardRoadmapService = null) : IPracticeQuizService
{
    public const double MinimumPassingScorePercent = LessonPracticeProgress.PassingScore;

    public Task<ApiResponse<IReadOnlyList<PracticeExerciseSummaryResponse>>> GetLessonExercisesAsync(
        int lessonId, CancellationToken cancellationToken)
        => LoadLessonExercisesAsync(lessonId, cancellationToken);

    public Task<ApiResponse<IReadOnlyList<PracticeExerciseSummaryResponse>>> GetAssessmentRoadmapExercisesAsync(
        int lessonId, CancellationToken cancellationToken)
        => LoadLessonExercisesAsync(lessonId, cancellationToken, fromAssessmentRoadmap: true);

    private async Task<ApiResponse<IReadOnlyList<PracticeExerciseSummaryResponse>>> LoadLessonExercisesAsync(
        int lessonId, CancellationToken cancellationToken, bool fromAssessmentRoadmap = false)
    {
        if (lessonId <= 0)
            return ApiResponse<IReadOnlyList<PracticeExerciseSummaryResponse>>.Fail("LessonId không hợp lệ.");

        try
        {
            if (fromAssessmentRoadmap)
            {
                var access = await CheckAssessmentRoadmapLessonAsync(lessonId, cancellationToken);
                if (!access.IsSuccess)
                    return ApiResponse<IReadOnlyList<PracticeExerciseSummaryResponse>>.Fail(
                        access.ErrorMessage!, (HttpStatusCode)access.StatusCode, access.ErrorCode);
            }

            var lesson = await unitOfWork.Lessons.GetLearnerVisibleByIdAsync(lessonId, cancellationToken);
            if (lesson is null)
                return ApiResponse<IReadOnlyList<PracticeExerciseSummaryResponse>>.NotFound("Không tìm thấy lesson.");

            var userId = claimService.GetUserClaim().Id;
            var source = fromAssessmentRoadmap
                ? LessonPracticeProgress.ReadyExercises(unitOfWork)
                : unitOfWork.PracticeExercises.Query();
            var exercises = await source
                .Where(exercise => !exercise.IsDeleted && exercise.LessonId == lessonId)
                .OrderBy(exercise => exercise.SortOrder)
                .ThenBy(exercise => exercise.Id)
                .Select(exercise => new PracticeExerciseSummaryResponse
                {
                    Id = exercise.Id,
                    MinimumPassingScorePercent = MinimumPassingScorePercent,
                    Passed = unitOfWork.PracticeExerciseAttempts.Query().Any(attempt =>
                        !attempt.IsDeleted && attempt.UserId == userId && attempt.HomeworkAssignmentId == null &&
                        attempt.IsCompleted &&
                        attempt.PracticeExerciseId == exercise.Id && attempt.ScorePercent >= MinimumPassingScorePercent),
                    LessonId = exercise.LessonId,
                    Title = exercise.Title,
                    ImageUrl = exercise.ImageUrl,
                    Description = exercise.Description,
                    LanguageSkillName = exercise.LanguageSkill.Name,
                    QuestionCount = exercise.Questions!.Count(question => !question.IsDeleted),
                })
                .ToListAsync(cancellationToken);

            return ApiResponse<IReadOnlyList<PracticeExerciseSummaryResponse>>.Success(exercises);
        }
        catch (OperationCanceledException) { throw; }
        catch
        {
            return ApiResponse<IReadOnlyList<PracticeExerciseSummaryResponse>>.Fail(
                "Không thể tải bài Practice Exercise của lesson.", HttpStatusCode.InternalServerError);
        }
    }

    public Task<ApiResponse<PracticeExerciseAttemptResponse>> StartAttemptAsync(
        int practiceExerciseId, CancellationToken cancellationToken, bool fromCatalog = false, string? skill = null)
        => StartAsync(practiceExerciseId, null, cancellationToken, fromCatalog, skill);

    public Task<ApiResponse<PracticeExerciseAttemptResponse>> StartHomeworkAttemptAsync(
        int assignmentId, int exerciseId, CancellationToken cancellationToken)
        => WithLearnerLockAsync(token => StartAsync(exerciseId, assignmentId, token), cancellationToken);

    public Task<ApiResponse<PracticeExerciseAttemptResponse>> StartAssessmentRoadmapAttemptAsync(
        int practiceExerciseId, CancellationToken cancellationToken)
        => StartAsync(practiceExerciseId, null, cancellationToken, fromAssessmentRoadmap: true);

    private async Task<ApiResponse<PracticeExerciseAttemptResponse>> StartAsync(
        int practiceExerciseId, int? assignmentId, CancellationToken cancellationToken, bool fromCatalog = false,
        string? skill = null, bool fromAssessmentRoadmap = false)
    {
        try
        {
            var userId = claimService.GetUserClaim().Id;
            if (assignmentId.HasValue && !await unitOfWork.HomeworkAssignments.Query().AnyAsync(assignment =>
                    assignment.Id == assignmentId && assignment.LearnerId == userId && !assignment.IsDeleted &&
                    assignment.Status == "Assigned" && assignment.Exercises.Any(link =>
                        link.PracticeExerciseId == practiceExerciseId), cancellationToken))
                return ApiResponse<PracticeExerciseAttemptResponse>.NotFound("Không tìm thấy bài luyện tập được giao.");

            var exercise = await unitOfWork.PracticeExercises.GetWithQuestionsAndOptionsAsync(
                practiceExerciseId, cancellationToken);
            var lesson = exercise is null || exercise.IsDeleted ? null :
                await unitOfWork.Lessons.GetLearnerVisibleByIdAsync(exercise.LessonId, cancellationToken);
            if (exercise is null || lesson is null)
                return ApiResponse<PracticeExerciseAttemptResponse>.NotFound("Không tìm thấy bài Practice Exercise.");

            if (!assignmentId.HasValue &&
                !await LessonPracticeProgress.HasStudiedAsync(unitOfWork, userId, lesson.Id, cancellationToken))
                return ApiResponse<PracticeExerciseAttemptResponse>.Fail(
                    "Hãy đánh dấu đã học xong bài trước khi làm bài luyện tập.",
                    HttpStatusCode.Conflict, "LESSON_STUDY_REQUIRED");

            if (fromAssessmentRoadmap)
            {
                var access = await CheckAssessmentRoadmapLessonAsync(lesson.Id, cancellationToken);
                if (!access.IsSuccess)
                    return ApiResponse<PracticeExerciseAttemptResponse>.Fail(
                        access.ErrorMessage!, (HttpStatusCode)access.StatusCode, access.ErrorCode);
            }
            else if (!assignmentId.HasValue && fromCatalog)
            {
                if (skill is not null && (skill is not ("Reading" or "Listening") || lesson.LanguageSkill.Name != skill))
                    return ApiResponse<PracticeExerciseAttemptResponse>.Fail("Kỹ năng ôn luyện không hợp lệ.");
                var catalog = await unitOfWork.Lessons.GetLearnerVisibleByLevelAsync(
                    lesson.CertificateLevelId, userId, cancellationToken);
                var preceding = catalog.Where(item => skill is null || item.LanguageSkill.Name == skill)
                    .TakeWhile(item => item.Id != lesson.Id).Select(item => item.Id).ToArray();
                if (!await LessonPracticeProgress.AllClearedAsync(unitOfWork, userId, preceding, cancellationToken))
                    return ApiResponse<PracticeExerciseAttemptResponse>.Fail(
                        "Hãy hoàn thành bài học trước để mở bài luyện tập này.",
                        HttpStatusCode.Conflict, "CATALOG_LESSON_LOCKED");
            }
            else if (!assignmentId.HasValue)
            {
                var path = await learningPathService.GetLatestLearningPathAsync(cancellationToken);
                var schedules = path.Result?.DailySchedules.OrderBy(day => day.Day).ToList();
                var lessonDay = schedules?.FirstOrDefault(day => day.IsStarted && !day.IsCompleted && day.LessonIds.Contains(lesson.Id))
                    ?? schedules?.FirstOrDefault(day => day.LessonIds.Contains(lesson.Id));
                if (lessonDay is not null)
                {
                    var preceding = lessonDay.LessonIds.TakeWhile(id => id != lesson.Id).Distinct().ToArray();
                    if (schedules!.Any(day => day.Day < lessonDay.Day && !day.IsCompleted) || !lessonDay.IsStarted ||
                        !await LessonPracticeProgress.AllClearedAsync(unitOfWork, userId, preceding, cancellationToken))
                        return ApiResponse<PracticeExerciseAttemptResponse>.Fail(
                            "Hãy hoàn thành bài học trước và bắt đầu ngày học này trước khi làm bài.",
                            HttpStatusCode.Conflict, "LEARNING_PATH_LESSON_LOCKED");
                }
            }

            var questions = GetVisibleQuestions(exercise);
            if (!CanTakeExercise(questions, fromAssessmentRoadmap))
                return ApiResponse<PracticeExerciseAttemptResponse>.Fail(
                    "Bài Practice Exercise chưa có đủ câu hỏi và lựa chọn để làm.", HttpStatusCode.Conflict);

            var attempt = assignmentId.HasValue
                ? await unitOfWork.PracticeExerciseAttempts.Query().SingleOrDefaultAsync(item =>
                    !item.IsDeleted && item.HomeworkAssignmentId == assignmentId &&
                    item.PracticeExerciseId == exercise.Id && item.UserId == userId, cancellationToken)
                : null;
            if (attempt?.IsCompleted == true)
                return ApiResponse<PracticeExerciseAttemptResponse>.Fail("Bài luyện tập này đã được nộp.",
                    HttpStatusCode.Conflict, "PRACTICE_ATTEMPT_ALREADY_SUBMITTED");

            if (attempt is null)
            {
                attempt = new PracticeExerciseAttempt
                {
                    UserId = userId,
                    PracticeExerciseId = exercise.Id,
                    HomeworkAssignmentId = assignmentId,
                    StartedAt = DateTime.UtcNow,
                };
                await unitOfWork.PracticeExerciseAttempts.AddAsync(attempt, cancellationToken);
                await unitOfWork.SaveChangesAsync(cancellationToken);
            }

            return ApiResponse<PracticeExerciseAttemptResponse>.Success(new PracticeExerciseAttemptResponse
            {
                AttemptId = attempt.Id,
                PracticeExerciseId = exercise.Id,
                ExerciseTitle = exercise.Title,
                ImageUrl = exercise.ImageUrl,

                LessonId = exercise.LessonId,
                Questions = questions.Select(question => new PracticeExerciseQuestionResponse
                {
                    QuestionId = question.Id,
                    QuestionText = question.QuestionText,
                            ImageUrl = question.ImageUrl,
                    SortOrder = question.SortOrder,
                    Options = (question.Options ?? []).Where(option => !option.IsDeleted)
                        .OrderBy(option => option.SortOrder)
                        .Select(option => new PracticeExerciseOptionResponse
                        {
                            OptionId = option.Id,
                            OptionText = option.OptionText,
                                    ImageUrl = option.ImageUrl,
                            SortOrder = option.SortOrder,
                        }).ToList(),
                }).ToList(),
            });
        }
        catch (OperationCanceledException) { throw; }
        catch
        {
            return ApiResponse<PracticeExerciseAttemptResponse>.Fail(
                "Không thể bắt đầu bài Practice Exercise.", HttpStatusCode.InternalServerError);
        }
    }

    public Task<ApiResponse<PracticeExerciseAttemptResultResponse>> SubmitAttemptAsync(
        int attemptId, SubmitPracticeExerciseAttemptRequest request, CancellationToken cancellationToken)
        => SubmitAsync(attemptId, null, request, cancellationToken);

    public Task<ApiResponse<PracticeExerciseAttemptResultResponse>> SubmitAssessmentRoadmapAttemptAsync(
        int attemptId, SubmitPracticeExerciseAttemptRequest request, CancellationToken cancellationToken)
        => SubmitAsync(attemptId, null, request, cancellationToken, fromAssessmentRoadmap: true);

    public Task<ApiResponse<PracticeExerciseAttemptResultResponse>> SubmitHomeworkAttemptAsync(
        int assignmentId, int attemptId, SubmitPracticeExerciseAttemptRequest request, CancellationToken cancellationToken)
        => WithLearnerLockAsync(token => SubmitAsync(attemptId, assignmentId, request, token), cancellationToken);

    private async Task<ApiResponse<PracticeExerciseAttemptResultResponse>> SubmitAsync(
        int attemptId, int? assignmentId, SubmitPracticeExerciseAttemptRequest request, CancellationToken cancellationToken,
        bool fromAssessmentRoadmap = false)
    {
        try
        {
            var userId = claimService.GetUserClaim().Id;
            var attempt = await unitOfWork.PracticeExerciseAttempts.GetByIdAsync(attemptId, cancellationToken);
            if (attempt is null || attempt.IsDeleted || attempt.UserId != userId || attempt.HomeworkAssignmentId != assignmentId)
                return ApiResponse<PracticeExerciseAttemptResultResponse>.NotFound("Không tìm thấy lượt làm bài.");
            if (assignmentId.HasValue && !await unitOfWork.HomeworkAssignments.Query().AnyAsync(assignment =>
                    assignment.Id == assignmentId && assignment.LearnerId == userId && !assignment.IsDeleted &&
                    assignment.Status == "Assigned", cancellationToken))
                return ApiResponse<PracticeExerciseAttemptResultResponse>.Fail("Bài tập đã đóng.",
                    HttpStatusCode.Conflict, "HOMEWORK_CLOSED");
            if (attempt.IsCompleted)
                return ApiResponse<PracticeExerciseAttemptResultResponse>.Fail(
                    "Lượt làm này đã được nộp. Hãy tạo lượt mới nếu muốn làm lại.",
                    HttpStatusCode.Conflict, "PRACTICE_ATTEMPT_ALREADY_SUBMITTED");

            var exercise = await unitOfWork.PracticeExercises.GetWithQuestionsAndOptionsAsync(
                attempt.PracticeExerciseId, cancellationToken);
            if (exercise is null || exercise.IsDeleted)
                return ApiResponse<PracticeExerciseAttemptResultResponse>.NotFound("Không tìm thấy bài Practice Exercise.");

            if (fromAssessmentRoadmap)
            {
                var access = await CheckAssessmentRoadmapLessonAsync(exercise.LessonId, cancellationToken);
                if (!access.IsSuccess)
                    return ApiResponse<PracticeExerciseAttemptResultResponse>.Fail(
                        access.ErrorMessage!, (HttpStatusCode)access.StatusCode, access.ErrorCode);
            }

            var questions = GetVisibleQuestions(exercise);
            if (questions.Count == 0)
                return ApiResponse<PracticeExerciseAttemptResultResponse>.Fail("Bài tập không có câu hỏi.");
            if (fromAssessmentRoadmap && !CanTakeExercise(questions, requireSingleCorrectOption: true))
                return ApiResponse<PracticeExerciseAttemptResultResponse>.Fail(
                    "Bài luyện tập chưa có bộ câu hỏi hợp lệ.", HttpStatusCode.Conflict);

            var suppliedAnswers = request.Answers ?? [];
            if (suppliedAnswers.GroupBy(answer => answer.QuestionId).Any(group => group.Count() > 1))
                return ApiResponse<PracticeExerciseAttemptResultResponse>.Fail("Không được gửi đáp án trùng câu hỏi.");
            if ((assignmentId.HasValue || fromAssessmentRoadmap) && (suppliedAnswers.Count != questions.Count ||
                suppliedAnswers.Any(answer => !answer.SelectedOptionId.HasValue)))
                return ApiResponse<PracticeExerciseAttemptResultResponse>.Fail("Hãy trả lời tất cả câu hỏi trước khi nộp.");

            var questionMap = questions.ToDictionary(question => question.Id);
            foreach (var answer in suppliedAnswers)
            {
                if (!questionMap.TryGetValue(answer.QuestionId, out var question))
                    return ApiResponse<PracticeExerciseAttemptResultResponse>.Fail(
                        "Có câu trả lời không thuộc bài tập này.");
                if (answer.SelectedOptionId.HasValue &&
                    !(question.Options ?? []).Any(option => !option.IsDeleted && option.Id == answer.SelectedOptionId.Value))
                    return ApiResponse<PracticeExerciseAttemptResultResponse>.Fail(
                        "Có lựa chọn trả lời không thuộc câu hỏi.");
            }

            var answerMap = suppliedAnswers.ToDictionary(answer => answer.QuestionId);
            var correctCount = 0;
            var persistedAnswers = new List<LearnerPracticeAnswer>(questions.Count);
            foreach (var question in questions)
            {
                answerMap.TryGetValue(question.Id, out var supplied);
                var selectedOption = supplied?.SelectedOptionId;
                var isCorrect = selectedOption.HasValue &&
                    (question.Options ?? []).Any(option => !option.IsDeleted &&
                        option.Id == selectedOption.Value && option.IsCorrect);
                if (isCorrect) correctCount++;
                persistedAnswers.Add(new LearnerPracticeAnswer
                {
                    PracticeExerciseAttemptId = attempt.Id,
                    PracticeQuestionId = question.Id,
                    SelectedOptionId = selectedOption,
                    IsCorrect = isCorrect,
                });
            }

            var scorePercent = Math.Round(correctCount * 100d / questions.Count, 2);
            attempt.ScorePercent = scorePercent;
            attempt.SubmittedAt = DateTime.UtcNow;
            attempt.IsCompleted = true;
            unitOfWork.PracticeExerciseAttempts.Update(attempt);
            await unitOfWork.LearnerPracticeAnswers.AddRangeAsync(persistedAnswers, cancellationToken);
            await unitOfWork.SaveChangesAsync(cancellationToken);

            var passed = scorePercent >= MinimumPassingScorePercent;
            var unlockedNextDay = false;
            if (passed && !assignmentId.HasValue && !fromAssessmentRoadmap)
            {
                var latestPath = await learningPathService.GetLatestLearningPathAsync(cancellationToken);
                var activeDay = latestPath.Result?.DailySchedules.FirstOrDefault(day =>
                    day.IsStarted && !day.IsCompleted && day.LessonIds.Contains(exercise.LessonId));
                if (activeDay is not null)
                {
                    var completion = await learningPathService.CompleteActiveDayAsync(
                        activeDay.Day, cancellationToken);
                    unlockedNextDay = completion.IsSuccess;
                }
            }

            return ApiResponse<PracticeExerciseAttemptResultResponse>.Success(new PracticeExerciseAttemptResultResponse
            {
                AttemptId = attempt.Id,
                PracticeExerciseId = exercise.Id,
                LessonId = exercise.LessonId,
                ScorePercent = scorePercent,
                CorrectCount = correctCount,
                TotalQuestions = questions.Count,
                MinimumPassingScorePercent = MinimumPassingScorePercent,
                Passed = passed,
                UnlocksNextLearningPathDay = unlockedNextDay,
            });
        }
        catch (OperationCanceledException) { throw; }
        catch
        {
            return ApiResponse<PracticeExerciseAttemptResultResponse>.Fail(
                "Không thể nộp bài Practice Exercise.", HttpStatusCode.InternalServerError);
        }
    }

    private Task<ApiResponse> CheckAssessmentRoadmapLessonAsync(int lessonId, CancellationToken cancellationToken)
        => (standardRoadmapService ?? new StandardRoadmapService(unitOfWork, claimService))
            .CheckAssessmentLessonAsync(lessonId, cancellationToken);

    private async Task<ApiResponse<T>> WithLearnerLockAsync<T>(
        Func<CancellationToken, Task<ApiResponse<T>>> operation, CancellationToken cancellationToken)
    {
        var response = ApiResponse<T>.NotFound("Không tìm thấy người học.");
        var userId = claimService.GetUserClaim().Id;
        await unitOfWork.ExecuteInTransactionAsync(async token =>
        {
            if (await unitOfWork.UserAccounts.GetByIdForUpdateAsync(userId, token) is { IsDeleted: false })
                response = await operation(token);
        }, cancellationToken);
        return response;
    }

    private static List<PracticeQuestion> GetVisibleQuestions(PracticeExercise exercise)
        => (exercise.Questions ?? []).Where(question => !question.IsDeleted)
            .OrderBy(question => question.SortOrder)
            .ThenBy(question => question.Id)
            .ToList();

    private static bool CanTakeExercise(List<PracticeQuestion> questions, bool requireSingleCorrectOption)
        => questions.Count > 0 && questions.All(question =>
            (question.Options ?? []).Count(option => !option.IsDeleted) >= 2 &&
            (!requireSingleCorrectOption ||
             (question.Options ?? []).Count(option => !option.IsDeleted && option.IsCorrect) == 1));
}
