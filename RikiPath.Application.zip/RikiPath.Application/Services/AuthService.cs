using RikiPath.Domain.Entities;
using RikiPath.Domain.Enums;
using Microsoft.IdentityModel.Tokens;
using RikiPath.Application.IRepositories;
using RikiPath.Application.Helpers;
using RikiPath.Application.IServices;
using RikiPath.Application.Requests.Auth;
using RikiPath.Application.Responses;
using RikiPath.Application.Responses.Auth;
using RikiPath.Domain;
using System.IdentityModel.Tokens.Jwt;
using System.Security.Claims;
using System.Security.Cryptography;
using System.Text;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.Extensions.Logging;

namespace RikiPath.Application.Services
{
    public partial class AuthService(
        IUnitOfWork unitOfWork,
        AppSettings appSettings,
        IEmailService emailService,
        IFirebaseAuthService firebaseAuthService,
        IMemoryCache memoryCache,
        IClaimService claimService,
        ILogger<AuthService>? logger = null) : IAuthService
    {
        private const int VerificationCodeLifetimeMinutes = 30;
        private const int ResendCooldownSeconds = 60;
        private const int MaxResendsPerHour = 5;

        public async Task<ApiResponse<RegisterResponse>> RegisterAsync(RegisterRequest request, CancellationToken cancellationToken)
        {
            try
            {
                var email = request.Email.Trim().ToLowerInvariant();
                var existingUser = await unitOfWork.UserAccounts.GetByEmailAsync(email);
                if (existingUser is not null)
                    return ApiResponse<RegisterResponse>.Fail("Email này đã được đăng ký.");

                var (hash, salt) = CreatePasswordHash(request.Password);
                var (firstName, lastName) = UserNameHelper.SplitFullName(request.FullName);
                var fullName = UserNameHelper.FormatFullName(firstName, lastName);

                var user = new UserAccount
                {
                    Email = email,
                    PasswordHash = hash,
                    PasswordSalt = salt,
                    FirstName = firstName,
                    LastName = lastName,
                    Role = Role.Learner, // ép cứng — tự đăng ký luôn là Learner
                    IsEmailVerified = false,
                };

                await unitOfWork.UserAccounts.AddAsync(user, cancellationToken);
                await unitOfWork.SaveChangesAsync(cancellationToken);

                var verificationCode = GenerateVerificationCode();
                await unitOfWork.EmailVerifications.AddAsync(new EmailVerification
                {
                    UserId = user.Id,
                    VerificationCode = verificationCode,
                    ExpiresAt = DateTime.UtcNow.AddMinutes(30),
                    IsUsed = false,
                }, cancellationToken);
                await unitOfWork.SaveChangesAsync(cancellationToken);

                var greetingName = string.IsNullOrEmpty(fullName) ? "bạn" : fullName;
                var emailContent = $"Xin chào {greetingName},<br/>Mã xác thực email của bạn là: " +
                                    $"<strong>{verificationCode}</strong>.<br/>Mã có hiệu lực trong 30 phút.";

                var emailResult = await emailService.SendValidationEmailAsync(user.Email, emailContent, cancellationToken);
                if (!emailResult.IsSuccess)
                    return ApiResponse<RegisterResponse>.Fail(
                        "Tạo tài khoản thành công nhưng gửi email xác thực thất bại.");

                return ApiResponse<RegisterResponse>.Created(new RegisterResponse { UserId = user.Id, FullName = fullName, Email = user.Email });
            }
            catch (Exception ex)
            {
                return ApiResponse<RegisterResponse>.Fail(
                    "Đăng ký thất bại.", System.Net.HttpStatusCode.InternalServerError, errors: BuildDebugErrors(ex));
            }
        }

        public async Task<ApiResponse<RegisterResponse>> RegisterWithFirebasePhoneAsync(FirebasePhoneAuthRequest request, CancellationToken cancellationToken)
        {
            try
            {
                var verified = await firebaseAuthService.VerifyPhoneIdTokenAsync(request.IdToken, cancellationToken);

                var existingUser = await unitOfWork.UserAccounts.FirstOrDefaultAsync(
                    u => u.FirebaseUid == verified.Uid || u.PhoneNumber == verified.PhoneNumber,
                    cancellationToken);

                if (existingUser is not null)
                    return ApiResponse<RegisterResponse>.Fail("Số điện thoại này đã được đăng ký, vui lòng đăng nhập.");

                var user = new UserAccount
                {
                    PhoneNumber = verified.PhoneNumber,
                    FirebaseUid = verified.Uid,
                    IsPhoneVerified = true,
                    Role = Role.Learner,
                    IsEmailVerified = false,
                };

                await unitOfWork.UserAccounts.AddAsync(user, cancellationToken);
                await unitOfWork.SaveChangesAsync(cancellationToken);

                return ApiResponse<RegisterResponse>.Created(new RegisterResponse
                {
                    UserId = user.Id,
                    FullName = UserNameHelper.FormatFullName(user.FirstName, user.LastName),
                    PhoneNumber = user.PhoneNumber,
                });
            }
            catch (Exception ex)
            {
                return ApiResponse<RegisterResponse>.Fail(
                    "Đăng ký bằng số điện thoại thất bại.", System.Net.HttpStatusCode.InternalServerError, errors: BuildDebugErrors(ex));
            }
        }

        public async Task<ApiResponse> ResendVerificationEmailAsync(
            ResendVerificationEmailRequest request,
            CancellationToken cancellationToken)
        {
            try
            {
                var normalizedEmail = request.Email.Trim().ToLowerInvariant();
                var rateLimitKey = $"email-verification-resend:{normalizedEmail}";

                if (memoryCache.TryGetValue<ResendAttemptState>(rateLimitKey, out var state) && state is not null)
                {
                    if (DateTime.UtcNow < state.NextAllowedAt)
                        return ApiResponse.Fail(
                            $"Vui lòng chờ {Math.Ceiling((state.NextAllowedAt - DateTime.UtcNow).TotalSeconds)} giây trước khi gửi lại.");

                    if (state.Attempts.Count >= MaxResendsPerHour)
                        return ApiResponse.Fail("Bạn đã vượt quá số lần gửi lại email trong 1 giờ. Vui lòng thử lại sau.");
                }

                var user = await unitOfWork.UserAccounts.GetByEmailAsync(normalizedEmail);
                if (user is null)
                    return ApiResponse.Fail("Không thể gửi email xác thực. Vui lòng kiểm tra lại địa chỉ email.");

                if (user.IsEmailVerified)
                    return ApiResponse.Fail("Email này đã được xác thực.");

                var pendingVerifications = await unitOfWork.EmailVerifications.FindAsync(
                    x => x.UserId == user.Id && !x.IsUsed,
                    cancellationToken);
                foreach (var verification in pendingVerifications)
                    verification.IsUsed = true;

                if (pendingVerifications.Count > 0)
                    unitOfWork.EmailVerifications.UpdateRange(pendingVerifications);

                var verificationCode = GenerateVerificationCode();
                await unitOfWork.EmailVerifications.AddAsync(new EmailVerification
                {
                    UserId = user.Id,
                    VerificationCode = verificationCode,
                    ExpiresAt = DateTime.UtcNow.AddMinutes(VerificationCodeLifetimeMinutes),
                    IsUsed = false,
                }, cancellationToken);
                await unitOfWork.SaveChangesAsync(cancellationToken);

                var now = DateTime.UtcNow;
                var attempts = state?.Attempts
                    .Where(attempt => attempt > now.AddHours(-1))
                    .ToList() ?? [];
                attempts.Add(now);
                memoryCache.Set(
                    rateLimitKey,
                    new ResendAttemptState(now.AddSeconds(ResendCooldownSeconds), attempts),
                    TimeSpan.FromHours(1));

                var greetingName = UserNameHelper.FormatFullName(user.FirstName, user.LastName);
                var emailContent = $"Xin chào {(string.IsNullOrEmpty(greetingName) ? "bạn" : greetingName)},<br/>Mã xác thực email của bạn là: " +
                                   $"<strong>{verificationCode}</strong>.<br/>Mã có hiệu lực trong {VerificationCodeLifetimeMinutes} phút.";
                var emailResult = await emailService.SendValidationEmailAsync(
                    user.Email!,
                    emailContent,
                    cancellationToken);

                if (!emailResult.IsSuccess)
                    return ApiResponse.Fail(
                        // Nội dung xác minh luôn do server tạo; không nhận subject/HTML từ client.
                        "Không thể gửi email xác thực.",
                        System.Net.HttpStatusCode.BadRequest);

                return ApiResponse.Success();
            }
            catch (Exception ex)
            {
                return ApiResponse.Fail(
                    "Gửi lại email xác thực thất bại.",
                    System.Net.HttpStatusCode.InternalServerError,
                    errors: BuildDebugErrors(ex));
            }
        }

        public async Task<ApiResponse> VerifyEmailAsync(VerifyEmailRequest request, CancellationToken cancellationToken)
        {
            try
            {
                var record = await unitOfWork.EmailVerifications.GetValidCodeAsync(request.UserId, request.VerificationCode);
                if (record is null)
                    return ApiResponse.Fail("Mã xác thực không hợp lệ hoặc đã được sử dụng.");

                if (record.ExpiresAt < DateTime.UtcNow)
                    return ApiResponse.Fail("Mã xác thực đã hết hạn.");

                var user = await unitOfWork.UserAccounts.GetByIdAsync(request.UserId, cancellationToken);
                if (user is null)
                    return ApiResponse.NotFound("Không tìm thấy người dùng.");

                record.IsUsed = true;
                unitOfWork.EmailVerifications.Update(record);

                user.IsEmailVerified = true;
                unitOfWork.UserAccounts.Update(user);

                await unitOfWork.SaveChangesAsync(cancellationToken);

                return ApiResponse.Success();
            }
            catch (Exception ex)
            {
                return ApiResponse.Fail(
                    "Xác thực email thất bại.", System.Net.HttpStatusCode.InternalServerError, errors: BuildDebugErrors(ex));
            }
        }

        private sealed record ResendAttemptState(DateTime NextAllowedAt, List<DateTime> Attempts);

        public async Task<ApiResponse<LoginResponse>> LoginAsync(LoginRequest request, CancellationToken cancellationToken)
        {
            try
            {
                var user = await unitOfWork.UserAccounts.GetByEmailAsync(request.Email);
                if (user is null || user.IsDeleted || !VerifyPasswordHash(request.Password, user.PasswordHash, user.PasswordSalt))
                    return ApiResponse<LoginResponse>.Fail("Email hoặc mật khẩu không đúng.");

                if (!user.IsEmailVerified)
                    return ApiResponse<LoginResponse>.Fail("Vui lòng xác thực email trước khi đăng nhập.");

                var response = new LoginResponse
                {
                    AccessToken = CreateToken(user),
                    UserId = user.Id,
                    Email = user.Email,
                    FullName = UserNameHelper.FormatFullName(user.FirstName, user.LastName),
                    Role = user.Role.ToString(),
                };

                return ApiResponse<LoginResponse>.Success(response);
            }
            catch (Exception ex)
            {
                return ApiResponse<LoginResponse>.Fail(
                    "Đăng nhập thất bại.", System.Net.HttpStatusCode.InternalServerError, errors: BuildDebugErrors(ex));
            }
        }


        public async Task<ApiResponse<LoginResponse>> LoginWithFirebasePhoneAsync(FirebasePhoneAuthRequest request, CancellationToken cancellationToken)
        {
            try
            {
                var verified = await firebaseAuthService.VerifyPhoneIdTokenAsync(request.IdToken, cancellationToken);

                var user = await unitOfWork.UserAccounts.FirstOrDefaultAsync(
                    u => u.FirebaseUid == verified.Uid || u.PhoneNumber == verified.PhoneNumber,
                    cancellationToken);

                if (user is null)
                    return ApiResponse<LoginResponse>.Fail("Số điện thoại chưa được đăng ký, vui lòng đăng ký trước khi đăng nhập.");

                // Đồng bộ lại FirebaseUid phòng trường hợp user đổi thiết bị/app re-verify OTP lần nữa.
                user.FirebaseUid = verified.Uid;
                unitOfWork.UserAccounts.Update(user);
                await unitOfWork.SaveChangesAsync(cancellationToken);

                var response = new LoginResponse
                {
                    AccessToken = CreateToken(user),
                    UserId = user.Id,
                    Email = user.Email,
                    PhoneNumber = user.PhoneNumber,
                    FullName = UserNameHelper.FormatFullName(user.FirstName, user.LastName),
                    Role = user.Role.ToString(),
                };

                return ApiResponse<LoginResponse>.Success(response);
            }
            catch (Exception ex)
            {
                return ApiResponse<LoginResponse>.Fail(
                    "Đăng nhập bằng số điện thoại thất bại.", System.Net.HttpStatusCode.InternalServerError, errors: BuildDebugErrors(ex));
            }
        }

        public async Task<ApiResponse> UpdateEmailAsync(int userId, UpdateEmailRequest request, CancellationToken cancellationToken)
        {
            try
            {
                // User thường chỉ được cập nhật email của chính mình.
                // Admin được phép cập nhật email tài khoản khác theo nghiệp vụ quản trị.
                var ownershipError = ValidateAccountOwnership(userId, allowAdminEmailOverride: true);
                if (ownershipError is not null)
                    return ownershipError;

                var user = await unitOfWork.UserAccounts.GetByIdAsync(userId, cancellationToken);
                if (user is null)
                    return ApiResponse.NotFound("Không tìm thấy người dùng.");

                var newEmail = request.NewEmail.Trim().ToLowerInvariant();
                if (await unitOfWork.UserAccounts.GetByEmailAsync(newEmail) is not null)
                    return ApiResponse.Fail("Email mới đã được sử dụng bởi tài khoản khác.");

                user.Email = newEmail;
                user.IsEmailVerified = false;
                unitOfWork.UserAccounts.Update(user);

                var verificationCode = GenerateVerificationCode();
                await unitOfWork.EmailVerifications.AddAsync(new EmailVerification
                {
                    UserId = user.Id,
                    VerificationCode = verificationCode,
                    ExpiresAt = DateTime.UtcNow.AddMinutes(30),
                    IsUsed = false,
                }, cancellationToken);
                await unitOfWork.SaveChangesAsync(cancellationToken);

                var emailContent = $"Mã xác thực email mới của bạn là: <strong>{verificationCode}</strong>." +
                                    "<br/>Mã có hiệu lực trong 30 phút.";
                var emailResult = await emailService.SendValidationEmailAsync(user.Email, emailContent, cancellationToken);
                if (!emailResult.IsSuccess)
                    return ApiResponse.Fail("Đã cập nhật email nhưng gửi mã xác thực thất bại.");

                return ApiResponse.Success();
            }
            catch (Exception ex)
            {
                return ApiResponse.Fail(
                    "Cập nhật email thất bại.", System.Net.HttpStatusCode.InternalServerError, errors: BuildDebugErrors(ex));
            }
        }

        public async Task<ApiResponse> ChangePasswordAsync(int userId, ChangePasswordRequest request, CancellationToken cancellationToken)
        {
            try
            {
                // Mật khẩu chỉ được thay đổi bởi chính chủ tài khoản.
                // Admin không được phép đổi mật khẩu của người dùng khác.
                var ownershipError = ValidateAccountOwnership(userId, allowAdminEmailOverride: false);
                if (ownershipError is not null)
                    return ownershipError;

                var user = await unitOfWork.UserAccounts.GetByIdAsync(userId, cancellationToken);
                if (user is null)
                    return ApiResponse.NotFound("Không tìm thấy người dùng.");

                if (!VerifyPasswordHash(request.CurrentPassword, user.PasswordHash, user.PasswordSalt))
                    return ApiResponse.Fail("Mật khẩu hiện tại không đúng.");

                var (hash, salt) = CreatePasswordHash(request.NewPassword);
                user.PasswordHash = hash;
                user.PasswordSalt = salt;
                unitOfWork.UserAccounts.Update(user);

                await unitOfWork.SaveChangesAsync(cancellationToken);

                return ApiResponse.Success();
            }
            catch (Exception ex)
            {
                return ApiResponse.Fail(
                    "Đổi mật khẩu thất bại.", System.Net.HttpStatusCode.InternalServerError, errors: BuildDebugErrors(ex));
            }
        }

        // ---------- Private helpers ----------

        private ApiResponse? ValidateAccountOwnership(int targetUserId, bool allowAdminEmailOverride)
        {
            try
            {
                // userId trên route chỉ xác định tài khoản đích; quyền sở hữu phải được đối chiếu với JWT trước khi đọc hoặc cập nhật dữ liệu.
                var currentUser = claimService.GetUserClaim();

                var isOwner = currentUser.Id == targetUserId;
                var isAdminEmailOverride = allowAdminEmailOverride && currentUser.Role == Role.Admin;

                return isOwner || isAdminEmailOverride
                    ? null
                    : ApiResponse.Forbidden("Bạn không có quyền thay đổi tài khoản này.");
            }
            catch (Exception ex) when (ex is ArgumentException or FormatException)
            {
                return ApiResponse.Unauthorized("Không xác định được tài khoản hiện tại từ JWT.");
            }
        }


        private string CreateToken(UserAccount user)
        {
            List<Claim> claims =
            [
                new(ClaimTypes.NameIdentifier, user.Id.ToString()),
                new(ClaimTypes.Email, user.Email),
                new(ClaimTypes.Role, user.Role.ToString()),
            ];

            var key = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(appSettings.SecretToken.Value));
            var creds = new SigningCredentials(key, SecurityAlgorithms.HmacSha512Signature);

            var token = new JwtSecurityToken(
                claims: claims,
                expires: DateTime.UtcNow.AddDays(1),
                signingCredentials: creds);

            return new JwtSecurityTokenHandler().WriteToken(token);
        }

        private static (byte[] Hash, byte[] Salt) CreatePasswordHash(string password)
        {
            using var hmac = new HMACSHA512();
            var salt = hmac.Key;
            var hash = hmac.ComputeHash(Encoding.UTF8.GetBytes(password));
            return (hash, salt);
        }

        private static bool VerifyPasswordHash(string password, byte[] passwordHash, byte[] passwordSalt)
        {
            if (passwordHash is not { Length: 64 } || passwordSalt is not { Length: > 0 }) return false;
            using var hmac = new HMACSHA512(passwordSalt);
            var computedHash = hmac.ComputeHash(Encoding.UTF8.GetBytes(password));
            return CryptographicOperations.FixedTimeEquals(computedHash, passwordHash);
        }

        private static string GenerateVerificationCode() => Random.Shared.Next(100000, 999999).ToString();

        private static List<string> BuildDebugErrors(Exception ex)
        {
            var errors = new List<string> { $"{ex.GetType().Name}: {ex.Message}" };
            if (ex.InnerException is not null)
                errors.Add($"Inner: {ex.InnerException.Message}");
#if DEBUG
            if (!string.IsNullOrEmpty(ex.StackTrace))
                errors.Add(ex.StackTrace);
#endif
            return errors;
        }
    }
}
