using System.Net;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Logging;
using RikiPath.Application.IClients;
using RikiPath.Application.IServices;
using RikiPath.Application.Requests.MentorMeetings;
using RikiPath.Application.Responses;
using RikiPath.Application.Responses.MentorMeetings;
using RikiPath.Domain;
using RikiPath.Domain.Entities;
using RikiPath.Domain.Enums;
using RikiPath.Domain.MentorCompensation;

namespace RikiPath.Application.Services;

/// <summary>Owns Mentor Meeting validation, booking lifecycle, checkout orchestration, and response mapping.</summary>
public sealed partial class MentorMeetingService(
    IUnitOfWork unitOfWork,
    IPaymentGatewayClient paymentGateway,
    IClaimService claimService,
    AppSettings appSettings,
    ILogger<MentorMeetingService> logger,
    IMentorCreditLedgerService creditLedgerService,
    IHostEnvironment? hostEnvironment = null) : IMentorMeetingService
{
    private const int MinAdvanceMonths = 1;

    private const int MinCancelAdvanceDays = 7;

    private const int SlotMinutes = 60;

    private const int MaxBulkSlots = 50;

    private static readonly TimeSpan MaxSlotDuration = TimeSpan.FromHours(4);

    private bool IsQaPaymentSimulatorEnabled()
    {
        if (hostEnvironment is null) return false;
        return QaPaymentSimulatorGuard.IsEnabled(appSettings, hostEnvironment);
    }

    public Task<ApiResponse<List<BookableMentorResponse>>> GetMentorsAsync(CancellationToken cancellationToken = default)
        => GetMentorsAsync(null, cancellationToken);

    public async Task<ApiResponse<List<BookableMentorResponse>>> GetMentorsAsync(
        string? jlptLevel, CancellationToken cancellationToken = default)
    {
        int? requiredLevelId = null;
        if (!string.IsNullOrWhiteSpace(jlptLevel))
        {
            if (!MentorCompensationPolicy.TryNormalizeSupportedLevel(jlptLevel, out var normalizedLevel))
            {
                return ApiResponse<List<BookableMentorResponse>>.Fail(
                    "Chỉ hỗ trợ lọc cố vấn dạy trình độ JLPT N5, N4, N3 hoặc N2 (không hỗ trợ N1).",
                    HttpStatusCode.BadRequest);
            }

            requiredLevelId = await ResolveCertificateLevelIdAsync(normalizedLevel, cancellationToken);
        }

        var mentors = await unitOfWork.UserAccounts.Query()
            .Include(x => x.MentorProfile)
            .Where(x => x.Role == Role.Mentor && !x.IsDeleted && (x.MentorProfile == null || x.MentorProfile.VerificationStatus == MentorVerificationStatus.Approved))
            .ToListAsync(cancellationToken);

        var mentorIds = mentors.Select(x => x.Id).ToList();
        var teachingLevelsByMentor = new Dictionary<int, List<string>>();
        if (mentorIds.Count > 0 && unitOfWork.MentorTeachingQualifications != null)
        {
            var qualifications = await unitOfWork.MentorTeachingQualifications.Query()
                .Include(q => q.CertificateLevel)
                .Where(q => q.IsActive && q.RevokedAtUtc == null && mentorIds.Contains(q.MentorUserId))
                .ToListAsync(cancellationToken);

            foreach (var group in qualifications.GroupBy(x => x.MentorUserId))
            {
                teachingLevelsByMentor[group.Key] = group
                    .Select(x => x.CertificateLevel?.Code ?? MentorPlanService.ResolveLevelCode(x.CertificateLevelId))
                    .Where(x => !string.IsNullOrWhiteSpace(x))
                    .Select(x => x!.Trim().ToUpperInvariant())
                    .Distinct()
                    .OrderBy(x => x)
                    .ToList();
            }

            if (requiredLevelId.HasValue)
            {
                var qualifiedMentorIds = qualifications
                    .Where(q => q.CertificateLevelId == requiredLevelId.Value)
                    .Select(q => q.MentorUserId)
                    .ToHashSet();
                mentors = mentors.Where(m => qualifiedMentorIds.Contains(m.Id)).ToList();
            }
        }

        return ApiResponse<List<BookableMentorResponse>>.Success(mentors
            .OrderBy(x => x.FirstName).ThenBy(x => x.LastName).ThenBy(x => x.Id)
            .Select(x => new BookableMentorResponse
            {
                Id = x.Id,
                Name = $"{x.FirstName} {x.LastName}".Trim(),
                AvatarUrl = x.AvatarUrl,
                TeachingJlptLevels = teachingLevelsByMentor.TryGetValue(x.Id, out var levels) ? levels : [],
                Headline = x.MentorProfile?.Expertise,
                Bio = x.MentorProfile?.Bio,
                TeachingMethod = x.MentorProfile?.Workplace
            }).ToList());
    }

    public Task<ApiResponse<List<MentorMeetingPlanResponse>>> GetPlansAsync(CancellationToken cancellationToken = default)
        => GetPlansAsync(null, cancellationToken);

    public async Task<ApiResponse<List<MentorMeetingPlanResponse>>> GetPlansAsync(
        string? jlptLevel, CancellationToken cancellationToken = default)
    {
        try
        {
            int? filterLevelId = null;
            if (!string.IsNullOrWhiteSpace(jlptLevel))
            {
                if (!MentorCompensationPolicy.TryNormalizeSupportedLevel(jlptLevel, out var normalizedLevel))
                {
                    return ApiResponse<List<MentorMeetingPlanResponse>>.Fail(
                        "Chỉ hỗ trợ gói tư vấn cho trình độ JLPT N5, N4, N3 hoặc N2 (không hỗ trợ N1).",
                        HttpStatusCode.BadRequest);
                }

                filterLevelId = await ResolveCertificateLevelIdAsync(normalizedLevel, cancellationToken);
            }

            var plans = await unitOfWork.SubscriptionPlans.GetMeetingPlansAsync(cancellationToken);
            if (filterLevelId.HasValue)
            {
                plans = plans.Where(p => p.CertificateLevelId == filterLevelId.Value).ToList();
            }

            return ApiResponse<List<MentorMeetingPlanResponse>>.Success(plans.Select(MapPlan).ToList());
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Could not load Mentor Meeting plans.");
            return ApiResponse<List<MentorMeetingPlanResponse>>.Fail("Không thể tải danh sách gói tư vấn.", HttpStatusCode.InternalServerError);
        }
    }

    public Task<ApiResponse<List<MentorAvailabilityResponse>>> GetAvailableSlotsAsync(
        DateTime from, DateTime to, int? mentorId, CancellationToken cancellationToken = default)
        => GetAvailableSlotsAsync(from, to, mentorId, null, cancellationToken);

    public async Task<ApiResponse<List<MentorAvailabilityResponse>>> GetAvailableSlotsAsync(
        DateTime from, DateTime to, int? mentorId, string? jlptLevel, CancellationToken cancellationToken = default)
    {
        if (to <= from || to - from > TimeSpan.FromDays(90))
            return ApiResponse<List<MentorAvailabilityResponse>>.Fail("Khoảng thời gian không hợp lệ (tối đa 90 ngày).");
        if (mentorId is <= 0)
            return ApiResponse<List<MentorAvailabilityResponse>>.Fail("Cố vấn được chọn không hợp lệ.");

        int? requiredLevelId = null;
        string? normalizedLevel = null;
        if (!string.IsNullOrWhiteSpace(jlptLevel))
        {
            if (!MentorCompensationPolicy.TryNormalizeSupportedLevel(jlptLevel, out var norm))
            {
                return ApiResponse<List<MentorAvailabilityResponse>>.Fail(
                    "Chỉ hỗ trợ đặt lịch tư vấn cho trình độ JLPT N5, N4, N3 hoặc N2 (không hỗ trợ N1).",
                    HttpStatusCode.BadRequest);
            }

            normalizedLevel = norm;
            requiredLevelId = await ResolveCertificateLevelIdAsync(norm, cancellationToken);
        }

        try
        {
            await ExpirePendingPaymentsAsync(cancellationToken);
            var slots = await unitOfWork.MentorAvailabilities.GetAvailableSlotsAsync(mentorId, from, to, cancellationToken);

            if (requiredLevelId.HasValue && unitOfWork.MentorTeachingQualifications != null)
            {
                var qualifiedMentorIds = await unitOfWork.MentorTeachingQualifications.Query()
                    .Where(q => q.IsActive && q.RevokedAtUtc == null && q.CertificateLevelId == requiredLevelId.Value)
                    .Select(q => q.MentorUserId)
                    .Distinct()
                    .ToListAsync(cancellationToken);

                var qualifiedSet = qualifiedMentorIds.ToHashSet();
                if (mentorId.HasValue && !qualifiedSet.Contains(mentorId.Value))
                {
                    return ApiResponse<List<MentorAvailabilityResponse>>.Fail(
                        $"Chuyên gia chưa được cấp quyền giảng dạy trình độ JLPT {normalizedLevel}.",
                        HttpStatusCode.Conflict);
                }

                slots = slots.Where(s => qualifiedSet.Contains(s.MentorId)).ToList();
            }

            return ApiResponse<List<MentorAvailabilityResponse>>.Success(slots.Select(MapAvailability).ToList());
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Could not load available Mentor Meeting slots.");
            return ApiResponse<List<MentorAvailabilityResponse>>.Fail("Không thể tải khung giờ trống của cố vấn.", HttpStatusCode.InternalServerError);
        }
    }

    public async Task<ApiResponse<MentorMeetingPurchaseResponse>> PurchaseAsync(
        PurchaseMentorPlanRequest request, CancellationToken cancellationToken = default)
    {
        if (request.SubscriptionPlanId <= 0)
            return ApiResponse<MentorMeetingPurchaseResponse>.Fail("Mã gói hỗ trợ phải lớn hơn 0.");
        if (request.MentorAvailabilityId is <= 0 || request.Question?.Length > 2000)
            return ApiResponse<MentorMeetingPurchaseResponse>.Fail("Khung giờ hoặc câu hỏi không hợp lệ.");

        try
        {
            var claims = claimService.GetUserClaim();
            if (claims.Role != Role.Learner)
                return ApiResponse<MentorMeetingPurchaseResponse>.Fail("Chỉ học viên mới có thể mua gói tư vấn.", HttpStatusCode.Forbidden);

            int? requestedLevelId = null;
            string? requestedLevelCode = null;
            if (!string.IsNullOrWhiteSpace(request.JlptLevel))
            {
                if (!MentorCompensationPolicy.TryNormalizeSupportedLevel(request.JlptLevel, out var norm))
                {
                    return ApiResponse<MentorMeetingPurchaseResponse>.Fail(
                        "Chỉ hỗ trợ mua gói tư vấn cho trình độ JLPT N5, N4, N3 hoặc N2 (không hỗ trợ N1).",
                        HttpStatusCode.BadRequest);
                }

                requestedLevelCode = norm;
                requestedLevelId = await ResolveCertificateLevelIdAsync(norm, cancellationToken);
            }

            var plan = await unitOfWork.SubscriptionPlans.GetMeetingPlanAsync(request.SubscriptionPlanId, cancellationToken);
            if (plan is null)
                return ApiResponse<MentorMeetingPurchaseResponse>.Fail("Không tìm thấy gói tư vấn đang mở bán.", HttpStatusCode.NotFound);
            if (plan.MeetingSessionCount is not (1 or 3))
                return ApiResponse<MentorMeetingPurchaseResponse>.Fail("Chỉ hỗ trợ gói 1 hoặc 3 buổi.");
            if (plan.Price <= 0 || plan.Price != decimal.Truncate(plan.Price) || plan.Price > int.MaxValue)
                return ApiResponse<MentorMeetingPurchaseResponse>.Fail("Giá gói phải là số tiền VND nguyên dương.");

            var planLevelCode = plan.CertificateLevel?.Code ?? MentorPlanService.ResolveLevelCode(plan.CertificateLevelId);
            if (plan.CertificateLevelId.HasValue)
            {
                if (!MentorCompensationPolicy.TryNormalizeSupportedLevel(planLevelCode, out var normalizedPlanLevel))
                {
                    return ApiResponse<MentorMeetingPurchaseResponse>.Fail(
                        "Gói tư vấn có trình độ JLPT không được hỗ trợ (chỉ hỗ trợ N5–N2, không hỗ trợ N1).",
                        HttpStatusCode.BadRequest);
                }
                planLevelCode = normalizedPlanLevel;

                if (requestedLevelId.HasValue && plan.CertificateLevelId.Value != requestedLevelId.Value)
                {
                    return ApiResponse<MentorMeetingPurchaseResponse>.Fail(
                        "Trình độ JLPT yêu cầu không khớp với trình độ của gói tư vấn đã chọn.",
                        HttpStatusCode.BadRequest);
                }
            }

            var effectiveCertificateLevelId = plan.CertificateLevelId ?? requestedLevelId;
            var effectiveJlptLevel = planLevelCode ?? requestedLevelCode;

            if (IsQaPaymentSimulatorEnabled())
            {
                if (request.IdempotencyKey is not { } idempotencyKey || idempotencyKey == Guid.Empty)
                    return ApiResponse<MentorMeetingPurchaseResponse>.Fail("IdempotencyKey hợp lệ là bắt buộc cho giao dịch QA.");

                await ExpirePendingPaymentsAsync(cancellationToken);
                UserSubscription? qaSubscription = null;
                var createdQaSubscription = false;
                await unitOfWork.ExecuteInTransactionAsync(async ct =>
                {
                    await unitOfWork.UserSubscriptions.AcquireQaPurchaseLockAsync(claims.Id, idempotencyKey, ct);
                    qaSubscription = await unitOfWork.UserSubscriptions.GetQaPurchaseAsync(claims.Id, idempotencyKey, ct);
                    if (qaSubscription is not null)
                    {
                        if (qaSubscription.SubscriptionPlanId != plan.Id)
                            return;
                        return;
                    }

                    var qaNow = DateTime.UtcNow;
                    qaSubscription = new UserSubscription
                    {
                        UserId = claims.Id,
                        SubscriptionPlanId = plan.Id,
                        SubscriptionPlan = plan,
                        CertificateLevelId = effectiveCertificateLevelId,
                        MentorId = null,
                        AmountPaid = plan.Price,
                        PaymentStatus = PaymentStatus.Pending,
                        PaymentTransactionId = $"QA_SIMULATED:PENDING:{idempotencyKey:N}",
                        MeetingSessionsIncluded = plan.MeetingSessionCount,
                        MeetingSessionsUsed = 0,
                        PaymentExpiresAt = qaNow.AddMinutes(15),
                        PurchasedAt = qaNow,
                        AiGradingQuota = plan.AiGradingQuota
                    };
                    await unitOfWork.UserSubscriptions.AddAsync(qaSubscription, ct);
                    await unitOfWork.SaveChangesAsync(ct);
                    createdQaSubscription = true;
                }, cancellationToken);

                if (qaSubscription is null || qaSubscription.SubscriptionPlanId != plan.Id ||
                    qaSubscription.PaymentStatus is not (PaymentStatus.Pending or PaymentStatus.Paid))
                    return ApiResponse<MentorMeetingPurchaseResponse>.Fail("IdempotencyKey đã được dùng cho giao dịch khác hoặc không thể tiếp tục.", HttpStatusCode.Conflict);

                logger.LogInformation("QA_SIMULATED pending purchase {SubscriptionId} for Learner {LearnerId}; no payment provider was contacted.", qaSubscription.Id, claims.Id);
                return ApiResponse<MentorMeetingPurchaseResponse>.Success(new MentorMeetingPurchaseResponse
                {
                    SubscriptionId = qaSubscription.Id,
                    BookingId = null,
                    OrderCode = qaSubscription.Id,
                    PlanName = plan.Name,
                    MeetingSessionCount = plan.MeetingSessionCount,
                    CertificateLevelId = qaSubscription.CertificateLevelId ?? effectiveCertificateLevelId,
                    JlptLevel = effectiveJlptLevel,
                    Features = plan.Features.Where(x => !x.IsDeleted).Select(MapFeature).ToList(),
                    Amount = plan.Price,
                    CheckoutUrl = "qa-simulator://no-payment",
                    PaymentLinkId = qaSubscription.PaymentTransactionId ?? string.Empty,
                    QrCode = $"RIKIPATH-QA-NO-TRANSFER|{qaSubscription.Id}|{idempotencyKey:N}",
                    PaymentExpiresAt = qaSubscription.PaymentExpiresAt,
                    IsQaSimulated = true,
                    PaymentSource = "QA_SIMULATED"
                }, createdQaSubscription ? HttpStatusCode.Created : HttpStatusCode.OK);
            }

            if (request.MentorAvailabilityId is not int slotId)
                return ApiResponse<MentorMeetingPurchaseResponse>.Fail("Hãy chọn khung giờ với mentor trước khi thanh toán.");

            await ExpirePendingPaymentsAsync(cancellationToken);
            var now = DateTime.UtcNow;
            var slot = await unitOfWork.MentorAvailabilities.GetAvailableSlotByIdAsync(slotId, now, cancellationToken);
            if (slot is null || slot.CancelRequestedAt is not null)
                return ApiResponse<MentorMeetingPurchaseResponse>.Fail("Khung giờ vừa hết chỗ. Hãy chọn lịch khác.", HttpStatusCode.Conflict);
            var checkoutDeadline = now.AddMinutes(15);
            var expiresAt = slot.StartTime < checkoutDeadline ? slot.StartTime : checkoutDeadline;

            var subscription = new UserSubscription
            {
                UserId = claims.Id,
                SubscriptionPlanId = plan.Id,
                SubscriptionPlan = plan,
                CertificateLevelId = effectiveCertificateLevelId,
                MentorId = null,
                AmountPaid = plan.Price,
                PaymentStatus = PaymentStatus.Pending,
                MeetingSessionsIncluded = plan.MeetingSessionCount,
                MeetingSessionsUsed = 0,
                PaymentExpiresAt = expiresAt,
                PendingMentorAvailability = slot,
                PendingMentorQuestion = request.Question?.Trim(),
                PurchasedAt = now,
                AiGradingQuota = plan.AiGradingQuota
            };
            if (slot.EndTime > now.AddDays(MentorPurchaseFinalizer.DurationDays(subscription)))
                return ApiResponse<MentorMeetingPurchaseResponse>.Fail("Khung giờ nằm ngoài thời hạn của gói.", HttpStatusCode.Conflict);

            slot.BookedCount++;
            await unitOfWork.UserSubscriptions.AddAsync(subscription, cancellationToken);
            try
            {
                await unitOfWork.SaveChangesAsync(cancellationToken);
            }
            catch (DbUpdateConcurrencyException)
            {
                return ApiResponse<MentorMeetingPurchaseResponse>.Fail("Khung giờ vừa thay đổi. Hãy chọn lại lịch.", HttpStatusCode.Conflict);
            }

            PaymentLinkResult checkout;
            try
            {
                var description = $"Mentor plan {subscription.Id}";
                if (description.Length > 25) description = description[..25];
                var payOs = appSettings.PayOs;
                var (returnUrl, cancelUrl) = BuildPayOsReturnUrls(subscription.Id, request.FrontendOrigin);
                if (payOs is null || string.IsNullOrWhiteSpace(returnUrl) || string.IsNullOrWhiteSpace(cancelUrl))
                    throw new InvalidOperationException("Thiếu cấu hình PayOS return/cancel URL.");

                checkout = await paymentGateway.CreatePaymentLinkAsync(
                    subscription.Id,
                    decimal.ToInt32(plan.Price),
                    description,
                    returnUrl,
                    cancelUrl,
                    cancellationToken);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "PayOS checkout creation failed for subscription {SubscriptionId}.", subscription.Id);
                MentorPurchaseFinalizer.MarkFailed(subscription);
                await unitOfWork.SaveChangesAsync(cancellationToken);
                return ApiResponse<MentorMeetingPurchaseResponse>.Fail("Không thể tạo liên kết thanh toán. Chưa cộng hoặc trừ lượt.", HttpStatusCode.BadGateway);
            }

            subscription.PaymentTransactionId = checkout.PaymentLinkId;
            await unitOfWork.SaveChangesAsync(cancellationToken);

            return ApiResponse<MentorMeetingPurchaseResponse>.Success(new MentorMeetingPurchaseResponse
            {
                SubscriptionId = subscription.Id,
                OrderCode = subscription.Id,
                PlanName = plan.Name,
                MeetingSessionCount = plan.MeetingSessionCount,
                CertificateLevelId = subscription.CertificateLevelId,
                JlptLevel = effectiveJlptLevel,
                Features = plan.Features.Where(x => !x.IsDeleted).Select(MapFeature).ToList(),
                Amount = plan.Price,
                CheckoutUrl = checkout.CheckoutUrl,
                PaymentLinkId = checkout.PaymentLinkId,
                QrCode = checkout.QrCode,
                PaymentExpiresAt = expiresAt
            }, HttpStatusCode.Created);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Could not create a Mentor Meeting purchase.");
            return ApiResponse<MentorMeetingPurchaseResponse>.Fail("Không thể tạo giao dịch mua gói tư vấn.", HttpStatusCode.InternalServerError);
        }
    }

    public async Task<ApiResponse<object>> CompleteQaPaymentAsync(int subscriptionId, CancellationToken cancellationToken = default)
    {
        var claims = claimService.GetUserClaim();
        if (claims.Role != Role.Admin)
            return ApiResponse<object>.Fail("Chỉ Admin QA được xác nhận thanh toán mô phỏng.", HttpStatusCode.Forbidden);
        if (!IsQaPaymentSimulatorEnabled())
            return ApiResponse<object>.Fail("Chức năng mô phỏng thanh toán QA hiện không khả dụng.", HttpStatusCode.NotFound);

        var subscription = await unitOfWork.UserSubscriptions.GetMeetingPurchaseWithBookingsAsync(subscriptionId, cancellationToken);
        if (subscription is null)
            return ApiResponse<object>.Fail("Không tìm thấy giao dịch.", HttpStatusCode.NotFound);
        if (subscription.PaymentStatus == PaymentStatus.Paid &&
            subscription.PaymentTransactionId?.StartsWith("QA_SIMULATED:", StringComparison.Ordinal) == true)
        {
            if (subscription.MeetingSessionsUsed < subscription.MeetingSessionsIncluded)
            {
                var existingGrant = await creditLedgerService.CreateGrantFromPaidSubscriptionAsync(subscriptionId, cancellationToken: cancellationToken);
                if (!existingGrant.IsSuccess)
                    return ApiResponse<object>.Fail("Thanh toán QA đã xác nhận nhưng chưa cấp được lượt tư vấn.", HttpStatusCode.InternalServerError);
            }
            return ApiResponse<object>.Success(new { subscriptionId, source = "QA_SIMULATED", status = "Paid" });
        }
        if (subscription.PaymentStatus != PaymentStatus.Pending ||
            subscription.PaymentExpiresAt <= DateTime.UtcNow ||
            subscription.PaymentTransactionId is not { } pendingMarker ||
            !pendingMarker.StartsWith("QA_SIMULATED:PENDING:", StringComparison.Ordinal))
            return ApiResponse<object>.Fail("Giao dịch không còn ở trạng thái Pending QA hợp lệ.", HttpStatusCode.Conflict);

        var paidMarker = pendingMarker.Replace("QA_SIMULATED:PENDING:", "QA_SIMULATED:", StringComparison.Ordinal);
        var paidAtUtc = DateTime.UtcNow;
        var durationDays = MentorPurchaseFinalizer.DurationDays(subscription);
        DateTime? endsAtUtc = durationDays > 0 ? paidAtUtc.AddDays(durationDays) : null;
        var affected = await unitOfWork.UserSubscriptions.CompleteQaPaymentIfPendingAsync(
            subscriptionId, pendingMarker, paidMarker, paidAtUtc, endsAtUtc, cancellationToken);
        if (affected == 0)
        {
            var current = await unitOfWork.UserSubscriptions.Query().AsNoTracking()
                .FirstOrDefaultAsync(x => x.Id == subscriptionId, cancellationToken);
            if (current?.PaymentStatus != PaymentStatus.Paid || current.PaymentTransactionId != paidMarker)
                return ApiResponse<object>.Fail("Giao dịch QA đã thay đổi; không thể hoàn tất.", HttpStatusCode.Conflict);
        }
        var grantResult = await creditLedgerService.CreateGrantFromPaidSubscriptionAsync(subscriptionId, cancellationToken: cancellationToken);
        if (!grantResult.IsSuccess)
            return ApiResponse<object>.Fail("Thanh toán QA đã xác nhận nhưng chưa cấp được lượt tư vấn.", HttpStatusCode.InternalServerError);

        logger.LogWarning("QA_SIMULATED payment completed for subscription {SubscriptionId}; no payment provider or webhook was used.", subscriptionId);
        return ApiResponse<object>.Success(new { subscriptionId, source = "QA_SIMULATED", status = "Paid" });
    }

    public async Task<ApiResponse<List<MentorMeetingPurchaseStatusResponse>>> GetMyPurchasesAsync(CancellationToken ct)
    {
        var user = claimService.GetUserClaim();
        if (user.Role != Role.Learner)
            return ApiResponse<List<MentorMeetingPurchaseStatusResponse>>.Fail("Chỉ học viên được xem lượt của mình.", HttpStatusCode.Forbidden);
        var ids = await unitOfWork.UserSubscriptions.Query().AsNoTracking()
            .Where(x => x.UserId == user.Id && !x.IsDeleted && x.MeetingSessionsIncluded > 0)
            .OrderByDescending(x => x.Id).Select(x => x.Id).ToListAsync(ct);
        var result = new List<MentorMeetingPurchaseStatusResponse>();
        foreach (var id in ids)
        {
            var purchase = await GetPurchaseStatusAsync(id, ct);
            if (!purchase.IsSuccess) return ApiResponse<List<MentorMeetingPurchaseStatusResponse>>.Fail("Không tải được số lượt.");
            result.Add(purchase.Result!);
        }
        return ApiResponse<List<MentorMeetingPurchaseStatusResponse>>.Success(result);
    }

    public async Task<ApiResponse<MentorMeetingPurchaseStatusResponse>> GetPurchaseStatusAsync(
        int subscriptionId, CancellationToken cancellationToken = default)
    {
        if (subscriptionId <= 0)
            return ApiResponse<MentorMeetingPurchaseStatusResponse>.Fail("Mã gói đã mua phải lớn hơn 0.");
        try
        {
            var learnerId = claimService.GetUserClaim().Id;
            var subscription = await unitOfWork.UserSubscriptions
                .GetMeetingSubscriptionWithBookingsAsync(subscriptionId, learnerId, cancellationToken);
            if (subscription is null)
                return ApiResponse<MentorMeetingPurchaseStatusResponse>.Fail("Không tìm thấy giao dịch.", HttpStatusCode.NotFound);

            var levelId = subscription.CertificateLevelId ?? subscription.SubscriptionPlan?.CertificateLevelId;
            var levelCode = subscription.CertificateLevel?.Code
                ?? subscription.SubscriptionPlan?.CertificateLevel?.Code
                ?? MentorPlanService.ResolveLevelCode(levelId);

            return ApiResponse<MentorMeetingPurchaseStatusResponse>.Success(new MentorMeetingPurchaseStatusResponse
            {
                SubscriptionId = subscription.Id,
                PlanName = subscription.SubscriptionPlan.Name,
                CertificateLevelId = levelId,
                JlptLevel = levelCode,
                PaymentStatus = subscription.PaymentStatus,
                IsCheckoutExpired = subscription.PaymentStatus == PaymentStatus.Pending
                    && subscription.PaymentExpiresAt is DateTime expiresAt && expiresAt <= DateTime.UtcNow,
                AmountPaid = subscription.AmountPaid,
                PaymentExpiresAt = subscription.PaymentExpiresAt,
                EndDate = subscription.EndDate,
                MentorId = subscription.MentorId,
                MeetingSessionsIncluded = subscription.MeetingSessionsIncluded,
                MeetingSessionsUsed = subscription.MeetingSessionsUsed,
                Bookings = subscription.MentorBookings.Select(x => MapBooking(x, learnerId)).ToList(),
                TransactionId = subscription.PaymentTransactionId,
                IsQaSimulated = subscription.PaymentTransactionId?.StartsWith("QA_SIMULATED:", StringComparison.Ordinal) == true ||
                    subscription.PaymentTransactionId?.StartsWith("QA_SIMULATED:PENDING:", StringComparison.Ordinal) == true,
                DemoQrPayload = subscription.PaymentTransactionId?.StartsWith("QA_SIMULATED:PENDING:", StringComparison.Ordinal) == true
                    ? $"RIKIPATH-QA-NO-TRANSFER|{subscription.Id}|{subscription.PaymentTransactionId.Split(':').Last()}"
                    : null
            });
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Could not load Mentor Meeting purchase status.");
            return ApiResponse<MentorMeetingPurchaseStatusResponse>.Fail("Không thể tải trạng thái giao dịch.", HttpStatusCode.InternalServerError);
        }
    }

    public async Task<ApiResponse<MentorMeetingPurchaseStatusResponse>> SyncPurchaseAsync(int subscriptionId, CancellationToken cancellationToken = default)
    {
        var claims = claimService.GetUserClaim();
        if (claims.Role != Role.Learner)
            return ApiResponse<MentorMeetingPurchaseStatusResponse>.Fail("Chỉ học viên được kiểm tra đơn mua của mình.", HttpStatusCode.Forbidden);
        var subscription = await unitOfWork.UserSubscriptions.GetMeetingSubscriptionWithBookingsAsync(subscriptionId, claims.Id, cancellationToken);
        if (subscription is null)
            return ApiResponse<MentorMeetingPurchaseStatusResponse>.Fail("Không tìm thấy giao dịch.", HttpStatusCode.NotFound);
        if (subscription.PaymentTransactionId?.StartsWith("QA_SIMULATED:", StringComparison.Ordinal) == true ||
            subscription.PaymentTransactionId?.StartsWith("QA_SIMULATED:PENDING:", StringComparison.Ordinal) == true)
            return await GetPurchaseStatusAsync(subscriptionId, cancellationToken);
        if (subscription.PaymentStatus == PaymentStatus.Pending && !string.IsNullOrWhiteSpace(subscription.PaymentTransactionId))
        {
            try
            {
                var information = await paymentGateway.GetPaymentInformationAsync(subscription.Id, cancellationToken);
                if (information.OrderCode != subscription.Id || information.Amount != subscription.AmountPaid
                    || information.PaymentLinkId != subscription.PaymentTransactionId)
                    return ApiResponse<MentorMeetingPurchaseStatusResponse>.Fail("Thông tin giao dịch PayOS không khớp đơn mua.", HttpStatusCode.Conflict);
                if (information.Status == "PAID" && information.AmountPaid >= subscription.AmountPaid)
                {
                    MentorPurchaseFinalizer.MarkPaid(subscription, appSettings, null);
                    await unitOfWork.SaveChangesAsync(cancellationToken);
                }
                else if (information.Status == "CANCELLED")
                {
                    MentorPurchaseFinalizer.MarkFailed(subscription);
                    await unitOfWork.SaveChangesAsync(cancellationToken);
                }
            }
            catch (Exception ex)
            {
                logger.LogWarning(ex, "Could not reconcile Mentor purchase {SubscriptionId}.", subscriptionId);
                return ApiResponse<MentorMeetingPurchaseStatusResponse>.Fail("Chưa kiểm tra được PayOS. Vui lòng thử lại; hệ thống chưa xác nhận thanh toán.", HttpStatusCode.BadGateway);
            }
        }
        if (subscription.PaymentStatus == PaymentStatus.Paid && subscription.MeetingSessionsUsed < subscription.MeetingSessionsIncluded)
        {
            var grantResult = await creditLedgerService.CreateGrantFromPaidSubscriptionAsync(subscriptionId, cancellationToken: cancellationToken);
            if (!grantResult.IsSuccess)
                return ApiResponse<MentorMeetingPurchaseStatusResponse>.Fail("Thanh toán đã xác nhận nhưng chưa cấp được lượt tư vấn.", HttpStatusCode.InternalServerError);
        }
        return await GetPurchaseStatusAsync(subscriptionId, cancellationToken);
    }

    public async Task<ApiResponse<List<MentorAvailabilityResponse>>> GetMyAvailabilityAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            var claims = claimService.GetUserClaim();
            if (claims.Role != Role.Mentor)
                return ApiResponse<List<MentorAvailabilityResponse>>.Fail("Chỉ cố vấn mới có thể xem lịch tư vấn của mình.", HttpStatusCode.Forbidden);
            var slots = await unitOfWork.MentorAvailabilities.GetByMentorAsync(claims.Id);
            return ApiResponse<List<MentorAvailabilityResponse>>.Success(slots.Select(MapAvailability).ToList());
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Could not load Mentor availability.");
            return ApiResponse<List<MentorAvailabilityResponse>>.Fail("Không thể tải lịch trống của bạn.", HttpStatusCode.InternalServerError);
        }
    }

    public async Task<ApiResponse<List<MentorAvailabilityResponse>>> CreateAvailabilityAsync(
        CreateMentorAvailabilityRequest request, CancellationToken cancellationToken = default)
    {
        var actor = claimService.GetUserClaim();
        if (actor.Role != Role.Mentor) return ApiResponse<List<MentorAvailabilityResponse>>.Fail("Chỉ Mentor được đăng ký lịch rảnh.", HttpStatusCode.Forbidden);
        if (request.StartTime.Kind != DateTimeKind.Utc || request.EndTime.Kind != DateTimeKind.Utc
            || request.StartTime <= DateTime.UtcNow || request.EndTime <= request.StartTime
            || request.EndTime - request.StartTime > TimeSpan.FromHours(8)
            || request.StartTime.AddHours(7).Date != request.EndTime.AddTicks(-1).AddHours(7).Date)
            return ApiResponse<List<MentorAvailabilityResponse>>.Fail("Chọn giờ rảnh trong tương lai, cùng ngày, tối đa 8 giờ và có múi giờ UTC.");
        var startDate = DateOnly.FromDateTime(request.StartTime.AddHours(7));
        var until = request.RepeatUntil ?? startDate;
        var days = request.Weekdays;
        if (until < startDate || until > startDate.AddDays(366)
            || (request.RepeatUntil.HasValue && (days is null || days.Count == 0 || days.Any(x => !Enum.IsDefined(x)))))
            return ApiResponse<List<MentorAvailabilityResponse>>.Fail("Chọn ngày lặp và hạn kết thúc tối đa một năm.");
        var rows = new List<MentorAvailability>();
        for (var day = startDate; day <= until; day = day.AddDays(1))
            if (!request.RepeatUntil.HasValue || days!.Contains(day.DayOfWeek))
            {
                var delta = day.DayNumber - startDate.DayNumber;
                rows.Add(new() { MentorId = actor.Id, StartTime = request.StartTime.AddDays(delta),
                    EndTime = request.EndTime.AddDays(delta), MaxLearners = 1, IsApproved = false });
            }
        if (rows.Count == 0 || rows.Count > 500) return ApiResponse<List<MentorAvailabilityResponse>>.Fail("Không có ngày phù hợp hoặc quá nhiều buổi.");
        try { return await CreateRows(); }
        catch (AvailabilityOverlapException) { return ApiResponse<List<MentorAvailabilityResponse>>.Fail("Có ngày/giờ trùng lịch; chưa lưu đăng ký nào.", HttpStatusCode.Conflict); }
        async Task<ApiResponse<List<MentorAvailabilityResponse>>> CreateRows()
        {
            await unitOfWork.ExecuteInTransactionAsync(async token =>
            {
                await unitOfWork.MentorAvailabilities.LockMentorScheduleAsync(actor.Id, token);
                foreach (var slot in rows)
                    if (await unitOfWork.MentorAvailabilities.HasOverlappingSlotAsync(actor.Id, slot.StartTime, slot.EndTime, token))
                        throw new AvailabilityOverlapException();
                await unitOfWork.MentorAvailabilities.AddRangeAsync(rows, token);
                await unitOfWork.SaveChangesAsync(token);
            }, cancellationToken);
            return ApiResponse<List<MentorAvailabilityResponse>>.Success(rows.Select(MapAvailability).ToList());
        }
    }
    private sealed class AvailabilityOverlapException : Exception;


    public async Task<ApiResponse<bool>> DeleteAvailabilityAsync(int id, CancellationToken cancellationToken)
    {
        try
        {
            var claims = claimService.GetUserClaim();
            var slot = await unitOfWork.MentorAvailabilities.GetByIdAsync(id, cancellationToken);
            if (slot == null || slot.IsDeleted)
                return ApiResponse<bool>.Fail("Không tìm thấy khung giờ.", HttpStatusCode.NotFound);
            if (slot.MentorId != claims.Id && claims.Role != Role.Admin)
                return ApiResponse<bool>.Fail("Bạn không có quyền xóa khung giờ này.", HttpStatusCode.Forbidden);
            if (slot.IsApproved || slot.BookedCount > 0)
                return ApiResponse<bool>.Fail("Lịch đã duyệt phải gửi yêu cầu điều chỉnh/hủy để Admin xem xét.", HttpStatusCode.Conflict);

            slot.IsDeleted = true;
            await unitOfWork.SaveChangesAsync(cancellationToken);
            return ApiResponse<bool>.Success(true);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Could not delete Mentor availability.");
            return ApiResponse<bool>.Fail("Không thể xóa lịch trống.", HttpStatusCode.InternalServerError);
        }
    }

    public async Task<ApiResponse<List<MentorAvailabilityResponse>>> RequestCancelAvailabilitiesAsync(
        CancelAvailabilitiesRequest request, CancellationToken cancellationToken = default)
    {
        var ids = NormalizeIds(request.Ids);
        if (ids.Count == 0 || ids.Count > MaxBulkSlots || ids.Any(x => x <= 0))
            return ApiResponse<List<MentorAvailabilityResponse>>.Fail($"Danh sách khung giờ không hợp lệ (cần từ 1 đến {MaxBulkSlots} khung giờ).");
        if (request.Reason?.Length > 1000)
            return ApiResponse<List<MentorAvailabilityResponse>>.Fail("Lý do hủy tối đa 1000 ký tự.");

        try
        {
            var claims = claimService.GetUserClaim();
            if (claims.Role != Role.Mentor)
                return ApiResponse<List<MentorAvailabilityResponse>>.Fail("Chỉ cố vấn mới có thể hủy lịch tư vấn của mình.", HttpStatusCode.Forbidden);

            await ExpirePendingPaymentsAsync(cancellationToken);
            var slots = await unitOfWork.MentorAvailabilities.Query()
                .Include(x => x.Mentor)
                .Where(x => ids.Contains(x.Id) && !x.IsDeleted && x.MentorId == claims.Id)
                .ToListAsync(cancellationToken);
            if (slots.Count != ids.Count)
                return ApiResponse<List<MentorAvailabilityResponse>>.Fail("Có khung giờ không tồn tại.", HttpStatusCode.NotFound);

            var now = DateTime.UtcNow;
            if (slots.Any(x => x.CancelRequestedAt is not null))
                return ApiResponse<List<MentorAvailabilityResponse>>.Fail("Có khung giờ đang chờ quản trị viên duyệt hủy.", HttpStatusCode.Conflict);
            if (slots.Any(x => x.StartTime - now < TimeSpan.FromDays(MinCancelAdvanceDays)))
                return ApiResponse<List<MentorAvailabilityResponse>>.Fail(
                    $"Chỉ được yêu cầu hủy trước giờ bắt đầu ít nhất {MinCancelAdvanceDays} ngày.", HttpStatusCode.Conflict);
            if ((await GetSlotIdsWithActiveBookingsAsync(slots, cancellationToken)).Count > 0)
                return ApiResponse<List<MentorAvailabilityResponse>>.Fail("Có khung giờ đã được đặt nên không thể hủy.", HttpStatusCode.Conflict);

            foreach (var slot in slots)
            {
                slot.CancelRequestedAt = now;
                slot.CancelReason = request.Reason?.Trim();
                slot.CancelRejectedAt = null;
                slot.CancelRejectionReason = null;
                slot.ModifiedDate = now;
                unitOfWork.MentorAvailabilities.Update(slot);
            }
            await unitOfWork.SaveChangesAsync(cancellationToken);
            return ApiResponse<List<MentorAvailabilityResponse>>.Success(slots.OrderBy(x => x.StartTime).Select(MapAvailability).ToList());
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Could not request cancel for Mentor availabilities.");
            return ApiResponse<List<MentorAvailabilityResponse>>.Fail("Không thể gửi yêu cầu hủy.", HttpStatusCode.InternalServerError);
        }
    }

    public async Task<ApiResponse<bool>> ReviewCancelAvailabilitiesAsync(
        List<int> ids, bool approve, string? rejectionReason, CancellationToken cancellationToken = default)
    {
        var distinctIds = NormalizeIds(ids);
        if (distinctIds.Count == 0 || distinctIds.Count > MaxBulkSlots || distinctIds.Any(x => x <= 0))
            return ApiResponse<bool>.Fail($"Danh sách khung giờ không hợp lệ (cần từ 1 đến {MaxBulkSlots} khung giờ).");
        if (rejectionReason?.Length > 1000)
            return ApiResponse<bool>.Fail("Lý do từ chối tối đa 1000 ký tự.");

        try
        {
            var claims = claimService.GetUserClaim();
            if (claims.Role != Role.Admin)
                return ApiResponse<bool>.Fail("Chỉ Admin mới được duyệt yêu cầu hủy.", HttpStatusCode.Forbidden);

            await ExpirePendingPaymentsAsync(cancellationToken);
            var slots = await unitOfWork.MentorAvailabilities.Query()
                .Where(x => distinctIds.Contains(x.Id) && !x.IsDeleted)
                .ToListAsync(cancellationToken);
            if (slots.Count != distinctIds.Count)
                return ApiResponse<bool>.Fail("Có khung giờ không tồn tại.", HttpStatusCode.NotFound);
            if (slots.Any(x => x.CancelRequestedAt is null))
                return ApiResponse<bool>.Fail("Có khung giờ chưa có yêu cầu hủy.", HttpStatusCode.Conflict);

            var now = DateTime.UtcNow;
            if (approve)
            {
                if ((await GetSlotIdsWithActiveBookingsAsync(slots, cancellationToken)).Count > 0)
                    return ApiResponse<bool>.Fail("Có khung giờ đã được đặt nên không thể duyệt hủy.", HttpStatusCode.Conflict);
            }

            foreach (var slot in slots)
            {
                if (approve)
                {
                    slot.IsDeleted = true;
                }
                else
                {
                    slot.CancelRequestedAt = null;
                    slot.CancelRejectedAt = now;
                    slot.CancelRejectionReason = rejectionReason?.Trim();
                }
                slot.ModifiedDate = now;
                unitOfWork.MentorAvailabilities.Update(slot);
            }
            await unitOfWork.SaveChangesAsync(cancellationToken);
            return ApiResponse<bool>.Success(true);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Could not review cancel requests for Mentor availabilities.");
            return ApiResponse<bool>.Fail("Không thể xử lý yêu cầu hủy.", HttpStatusCode.InternalServerError);
        }
    }

    public async Task<ApiResponse<List<MentorAvailabilityResponse>>> GetPendingAvailabilitiesAsync(CancellationToken cancellationToken = default)
    {
        try
        {
            var claims = claimService.GetUserClaim();
            if (claims.Role != Role.Admin)
                return ApiResponse<List<MentorAvailabilityResponse>>.Fail("Chỉ Admin mới xem được danh sách chờ duyệt.", HttpStatusCode.Forbidden);

            var slots = await unitOfWork.MentorAvailabilities.Query()
                .Include(x => x.Mentor)
                .Where(x => !x.IsDeleted && !x.IsApproved && x.RejectedAt == null && x.StartTime > DateTime.UtcNow)
                .OrderBy(x => x.MentorId).ThenBy(x => x.StartTime)
                .ToListAsync(cancellationToken);
            return ApiResponse<List<MentorAvailabilityResponse>>.Success(slots.Select(MapAvailability).ToList());
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Could not load pending Mentor availabilities.");
            return ApiResponse<List<MentorAvailabilityResponse>>.Fail("Không thể tải danh sách lịch chờ duyệt.", HttpStatusCode.InternalServerError);
        }
    }

    public async Task<ApiResponse<bool>> ReviewAvailabilitiesAsync(
        List<int> ids, bool approve, string? rejectionReason, CancellationToken cancellationToken = default)
    {
        var distinctIds = NormalizeIds(ids);
        if (distinctIds.Count == 0 || distinctIds.Count > MaxBulkSlots || distinctIds.Any(x => x <= 0))
            return ApiResponse<bool>.Fail($"Danh sách khung giờ không hợp lệ (cần từ 1 đến {MaxBulkSlots} khung giờ).");
        if (!approve && string.IsNullOrWhiteSpace(rejectionReason))
            return ApiResponse<bool>.Fail("Vui lòng nhập lý do từ chối.");
        if (rejectionReason?.Length > 1000)
            return ApiResponse<bool>.Fail("Lý do từ chối tối đa 1000 ký tự.");

        try
        {
            var claims = claimService.GetUserClaim();
            if (claims.Role != Role.Admin)
                return ApiResponse<bool>.Fail("Chỉ Admin mới được duyệt lịch.", HttpStatusCode.Forbidden);

            var user = await unitOfWork.UserAccounts.GetByIdAsync(claims.Id, cancellationToken);
            var adminName = user is not null ? $"{user.FirstName} {user.LastName}".Trim() : null;

            var slots = await unitOfWork.MentorAvailabilities.Query()
                .Where(x => distinctIds.Contains(x.Id) && !x.IsDeleted)
                .ToListAsync(cancellationToken);
            var now = DateTime.UtcNow;
            if (slots.Count != distinctIds.Count)
                return ApiResponse<bool>.Fail("Có khung giờ không tồn tại.", HttpStatusCode.NotFound);
            if (slots.Any(x => x.IsApproved || x.RejectedAt is not null))
                return ApiResponse<bool>.Fail("Có lịch đã được xử lý.", HttpStatusCode.Conflict);
            if (slots.Any(x => x.StartTime <= now))
                return ApiResponse<bool>.Fail("Có lịch đã quá hạn, không thể duyệt.", HttpStatusCode.Conflict);

            foreach (var slot in slots)
            {
                slot.IsApproved = approve;
                slot.RejectedAt = approve ? null : now;
                slot.RejectionReason = approve ? null : rejectionReason!.Trim();
                slot.AdminName = adminName;
                slot.ModifiedDate = now;
                unitOfWork.MentorAvailabilities.Update(slot);
            }
            await unitOfWork.SaveChangesAsync(cancellationToken);
            return ApiResponse<bool>.Success(true);
        }
        catch (Exception ex)
        {
            logger.LogError(ex, "Could not review Mentor availabilities.");
            return ApiResponse<bool>.Fail("Không thể xử lý duyệt lịch.", HttpStatusCode.InternalServerError);
        }
    }

    private async Task<int> ResolveCertificateLevelIdAsync(string normalizedLevel, CancellationToken ct)
    {
        if (unitOfWork.CertificateLevels != null)
        {
            var certLevel = await unitOfWork.CertificateLevels.Query()
                .FirstOrDefaultAsync(x => !x.IsDeleted && x.Code.ToUpper() == normalizedLevel, ct);
            if (certLevel != null)
                return certLevel.Id;
        }
        return MentorCompensationPolicy.ResolveDefaultCertificateLevelId(normalizedLevel);
    }

    private static List<int> NormalizeIds(List<int>? ids) => ids?.Distinct().ToList() ?? [];

    private async Task<HashSet<int>> GetSlotIdsWithActiveBookingsAsync(
        IReadOnlyCollection<MentorAvailability> slots, CancellationToken cancellationToken)
    {
        var result = slots.Where(x => x.BookedCount > 0).Select(x => x.Id).ToHashSet();
        var slotIds = slots.Select(x => x.Id).ToList();
        var bookedIds = await unitOfWork.MentorBookings.Query()
            .Where(b => b.MentorAvailabilityId != null
                && slotIds.Contains(b.MentorAvailabilityId.Value)
                && !b.IsDeleted
                && b.Status != MentorStatus.Cancelled)
            .Select(b => b.MentorAvailabilityId!.Value)
            .Distinct()
            .ToListAsync(cancellationToken);
        result.UnionWith(bookedIds);
        return result;
    }

    private async Task ExpirePendingPaymentsAsync(CancellationToken cancellationToken)
    {
        var now = DateTime.UtcNow;
        var expiredReservations = await unitOfWork.UserSubscriptions.Query()
            .Where(x => !x.IsDeleted && x.PaymentStatus == PaymentStatus.Pending
                && x.PendingMentorAvailabilityId != null && x.PaymentExpiresAt <= now)
            .Include(x => x.PendingMentorAvailability)
            .ToListAsync(cancellationToken);
        var expiredBookings = await unitOfWork.MentorBookings.GetExpiredPaymentHoldsAsync(now, cancellationToken);
        foreach (var subscription in expiredReservations)
            MentorPurchaseFinalizer.ReleaseReservation(subscription);
        foreach (var booking in expiredBookings)
            MentorPurchaseFinalizer.ReleaseLegacyBooking(booking);
        if (expiredReservations.Count > 0 || expiredBookings.Count > 0)
            await unitOfWork.SaveChangesAsync(cancellationToken);
    }

    private (string? ReturnUrl, string? CancelUrl) BuildPayOsReturnUrls(int subscriptionId, string? frontendOrigin)
    {
        var origin = AllowedFrontendOrigin(frontendOrigin);
        var returnBase = origin is null ? appSettings.PayOs?.WebReturnUrl : $"{origin}/consultation-receipt/";
        var cancelBase = origin is null ? appSettings.PayOs?.WebCancelUrl : $"{origin}/payment/cancel/";
        if (string.IsNullOrWhiteSpace(returnBase) || string.IsNullOrWhiteSpace(cancelBase)) return (null, null);
        var id = subscriptionId.ToString();
        return (
            Microsoft.AspNetCore.WebUtilities.QueryHelpers.AddQueryString(returnBase, "subscriptionId", id),
            Microsoft.AspNetCore.WebUtilities.QueryHelpers.AddQueryString(cancelBase, "subscriptionId", id));
    }

    private string? AllowedFrontendOrigin(string? origin)
    {
        if (string.IsNullOrWhiteSpace(origin) || !Uri.TryCreate(origin.Trim(), UriKind.Absolute, out var uri)) return null;
        if (uri.Scheme is not ("http" or "https")) return null;
        var allowed = uri.Host.Equals("localhost", StringComparison.OrdinalIgnoreCase)
            || uri.Host.EndsWith(".vercel.app", StringComparison.OrdinalIgnoreCase);
        if (!allowed && Uri.TryCreate(appSettings.FrontendBaseUrl, UriKind.Absolute, out var configured))
            allowed = string.Equals(configured.Host, uri.Host, StringComparison.OrdinalIgnoreCase);
        return allowed ? uri.GetLeftPart(UriPartial.Authority) : null;
    }

    private static MentorMeetingPlanResponse MapPlan(SubscriptionPlan plan) => new()
    {
        IsActive = plan.IsActive,
        Id = plan.Id,
        Name = plan.Name,
        Description = plan.Description,
        DurationDays = plan.MeetingSessionCount switch { 1 => 30, 3 => 90, _ => plan.DurationDays },
        Price = plan.Price,
        MeetingSessionCount = plan.MeetingSessionCount,
        CertificateLevelId = plan.CertificateLevelId,
        JlptLevel = plan.CertificateLevel?.Code ?? MentorPlanService.ResolveLevelCode(plan.CertificateLevelId),
        Features = plan.Features.Where(x => !x.IsDeleted).Select(MapFeature).ToList()
    };

    private static MentorMeetingFeatureResponse MapFeature(Feature feature) => new()
    {
        Id = feature.Id,
        Name = feature.Name,
        Description = feature.Description
    };

    private static MentorAvailabilityResponse MapAvailability(MentorAvailability slot) => new()
    {
        Id = slot.Id,
        MentorId = slot.MentorId,
        MentorName = $"{slot.Mentor?.FirstName} {slot.Mentor?.LastName}".Trim(),
        StartTime = slot.StartTime,
        EndTime = slot.EndTime,
        IsBooked = slot.IsFull,
        IsApproved = slot.IsApproved,
        RejectedAt = slot.RejectedAt,
        RejectionReason = slot.RejectionReason,
        BookedCount = slot.BookedCount,
        MaxLearners = slot.MaxLearners,
        AdminName = slot.AdminName,
        AdvanceDaysAtCreation = slot.CreatedDate is DateTime createdAt ? (int)(slot.StartTime - createdAt).TotalDays : 0,
        MeetsAdvanceRule = slot.CreatedDate is DateTime created && slot.StartTime >= created.AddMonths(MinAdvanceMonths),
        CancelRequestedAt = slot.CancelRequestedAt,
        CancelReason = slot.CancelReason,
        CancelRejectedAt = slot.CancelRejectedAt,
        CancelRejectionReason = slot.CancelRejectionReason,
        MentorWeeklyAvailabilityId = slot.MentorWeeklyAvailabilityId,
        PublishedAt = slot.PublishedAt,
        ChangeRequestReason = slot.ChangeRequestReason,
        ChangeRequestedAt = slot.ChangeRequestedAt,
        ChangeResolution = slot.ChangeResolution,
    };

    private static MentorBookingResponse MapBooking(MentorBooking booking, int currentUserId)
    {
        var isMentor = booking.MentorAvailability?.MentorId == currentUserId;
        var learner = booking.UserSubscription?.UserAccount;
        var mentor = booking.MentorAvailability?.Mentor;
        var levelId = booking.CompensationLevelId ?? booking.UserSubscription?.CertificateLevelId;
        var levelCode = booking.CompensationLevel?.Code
            ?? booking.UserSubscription?.CertificateLevel?.Code
            ?? MentorPlanService.ResolveLevelCode(levelId);

        return new MentorBookingResponse
        {
            Id = booking.Id,
            UserSubscriptionId = booking.UserSubscriptionId,
            MentorAvailabilityId = booking.MentorAvailabilityId,
            MentorId = booking.MentorAvailability?.MentorId,
            MentorName = mentor is null ? null : $"{mentor.FirstName} {mentor.LastName}".Trim(),
            LearnerId = isMentor ? booking.UserSubscription?.UserId : null,
            LearnerName = isMentor && learner is not null ? $"{learner.FirstName} {learner.LastName}".Trim() : null,
            Status = booking.Status,
            PaymentStatus = booking.UserSubscription?.PaymentStatus,
            ScheduledAt = booking.ScheduledAt,
            MeetingLink = booking.MeetingLink,
            RoomId = booking.MentorAvailability?.RoomId,
            Question = booking.Question,
            EndsAt = booking.MentorAvailability?.EndTime,
            AttendedAt = booking.AttendedAt,
            CreatedAt = booking.CreatedDate,
            CompensationLevelId = levelId,
            JlptLevel = levelCode,
            CreditGrantId = booking.CreditGrantId
        };
    }
}
