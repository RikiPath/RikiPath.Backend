﻿namespace RikiPath.Application.Responses.CertificateType
{
    public class CertificateTypeResponse
    {
        public int Id { get; set; }
        public string Name { get; set; } = string.Empty;
        public string? Description { get; set; }
        public int SortOrder { get; set; }
    }
}
