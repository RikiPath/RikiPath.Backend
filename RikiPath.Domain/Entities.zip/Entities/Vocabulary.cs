using RikiPath.Domain.Enums;
using RikiPath.Domain.Entities;
using System;
using System.Collections.Generic;

namespace RikiPath.Domain.Entities
{
    public class Vocabulary : Base
    {
        public int Id { get; set; }
        public string Word { get; set; }
        public string Reading { get; set; }
        public string Meaning { get; set; }
        public string? ExampleSentence { get; set; }
        public string? ExampleSentenceMeaning { get; set; }
        public string? AudioUrl { get; set; }

        public List<LessonVocabulary>? LessonVocabularies { get; set; }
        public List<LearnerNoteEntry>? LearnerNoteEntries { get; set; }
        public List<ContentLevelMapping>? ContentLevelMappings { get; set; }
    }
}