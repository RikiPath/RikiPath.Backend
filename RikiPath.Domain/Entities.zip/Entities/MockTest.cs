using RikiPath.Domain.Enums;
using RikiPath.Domain.Entities;
using System;
using System.Collections.Generic;

namespace RikiPath.Domain.Entities
{
    /// <summary>A timed, auto-scored mock JLPT practice test reproducing the official JLPT section structure.</summary>
    public class MockTest : Base
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public string? Description { get; set; }
        public int TimeLimitMinutes { get; set; }
        /// <summary>Indicates this published mock test is used for onboarding placement.</summary>

        public int CertificateLevelId { get; set; }
        public CertificateLevel CertificateLevel { get; set; }

        public List<MockTestSection>? Sections { get; set; }
    }
}
