namespace RikiPath.Domain.Entities
{
    /// <summary>Join entity: which Vocabulary a Lesson introduces. Composite key, no audit fields.</summary>
    public class LessonVocabulary
    {
        public int LessonId { get; set; }
        public Lesson Lesson { get; set; }
        public int VocabularyId { get; set; }
        public Vocabulary Vocabulary { get; set; }
    }
}
